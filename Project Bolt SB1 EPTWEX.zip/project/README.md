<content># PostIT Social Media Manager

A comprehensive social media management platform built with React, TypeScript, and Firebase.

## Features

- Multi-platform social media management (Facebook, Twitter, Instagram, YouTube)
- Post scheduling and analytics
- Team collaboration
- Dark mode support
- Responsive design

## Getting Started

1. Clone the repository
2. Copy `.env.example` to `.env` and fill in your API keys
3. Install dependencies:
   ```bash
   npm install
   ```
4. Start the development server:
   ```bash
   npm run dev
   ```

## Environment Setup

You'll need to set up accounts and get API keys from:

1. Firebase
2. Facebook Developer Console
3. Twitter Developer Portal
4. Instagram Basic Display API
5. YouTube Data API

## Development

The project uses:

- Vite for development and building
- React with TypeScript
- Tailwind CSS for styling
- Firebase for backend services
- React Query for data fetching
- Zustand for state management</content>