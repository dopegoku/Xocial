import { db } from './firebase';
import { User } from '../types';

export class UserService {
  async createUser(userData: Partial<User>): Promise<User> {
    const userRef = db.collection('users').doc(userData.id!);
    await userRef.set(userData);
    return userData as User;
  }

  async getUser(userId: string): Promise<User> {
    const userDoc = await db.collection('users').doc(userId).get();
    if (!userDoc.exists) {
      throw new Error('User not found');
    }
    return userDoc.data() as User;
  }

  async updateUser(userId: string, updates: Partial<User>): Promise<User> {
    const userRef = db.collection('users').doc(userId);
    await userRef.update(updates);
    const updatedDoc = await userRef.get();
    return updatedDoc.data() as User;
  }

  async deleteUser(userId: string): Promise<void> {
    await db.collection('users').doc(userId).delete();
  }
}