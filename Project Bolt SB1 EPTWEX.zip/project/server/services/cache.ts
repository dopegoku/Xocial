import Redis from 'ioredis';
import { config } from '../config';

class CacheService {
  private client: Redis;
  private defaultTTL: number = 3600; // 1 hour

  constructor() {
    this.client = new Redis(config.redis.url);
    
    this.client.on('error', (err) => {
      console.error('Redis Client Error:', err);
    });
  }

  async get(key: string): Promise<any> {
    const value = await this.client.get(key);
    return value ? JSON.parse(value) : null;
  }

  async set(key: string, value: any, ttl: number = this.defaultTTL): Promise<void> {
    await this.client.set(key, JSON.stringify(value), 'EX', ttl);
  }

  async del(key: string): Promise<void> {
    await this.client.del(key);
  }

  async flush(): Promise<void> {
    await this.client.flushall();
  }
}

export const cacheService = new CacheService();