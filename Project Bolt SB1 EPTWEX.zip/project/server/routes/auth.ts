import { Router } from 'express';
import { auth } from '../services/firebase';
import { validateAuthToken } from '../middleware/auth';
import { AuthController } from '../controllers/auth';

const router = Router();
const authController = new AuthController();

router.post('/signup', authController.signup);
router.post('/signin', authController.signin);
router.post('/signout', validateAuthToken, authController.signout);
router.get('/me', validateAuthToken, authController.getCurrentUser);
router.put('/profile', validateAuthToken, authController.updateProfile);

export = router;