import { Request, Response } from 'express';
import { auth, db } from '../services/firebase';
import { UserService } from '../services/user';

export class AuthController {
  private userService: UserService;

  constructor() {
    this.userService = new UserService();
  }

  signup = async (req: Request, res: Response) => {
    try {
      const { email, password, name } = req.body;
      const userRecord = await auth.createUser({
        email,
        password,
        displayName: name
      });

      const user = await this.userService.createUser({
        id: userRecord.uid,
        email: userRecord.email!,
        name: userRecord.displayName!,
        onboardingCompleted: false
      });

      res.status(201).json(user);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  };

  signin = async (req: Request, res: Response) => {
    try {
      const { email, password } = req.body;
      const userRecord = await auth.getUserByEmail(email);
      const user = await this.userService.getUser(userRecord.uid);
      
      res.json(user);
    } catch (error: any) {
      res.status(401).json({ error: 'Invalid credentials' });
    }
  };

  signout = async (req: Request, res: Response) => {
    try {
      // Handle session cleanup
      res.json({ message: 'Signed out successfully' });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  };

  getCurrentUser = async (req: Request, res: Response) => {
    try {
      const userId = req.user!.uid;
      const user = await this.userService.getUser(userId);
      res.json(user);
    } catch (error: any) {
      res.status(404).json({ error: 'User not found' });
    }
  };

  updateProfile = async (req: Request, res: Response) => {
    try {
      const userId = req.user!.uid;
      const updates = req.body;
      const updatedUser = await this.userService.updateUser(userId, updates);
      res.json(updatedUser);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  };
}