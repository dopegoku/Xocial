## Facebook App Setup Instructions

1. Go to https://developers.facebook.com/apps/

2. Click "Settings" > "Basic" in the left menu

3. Under "App Domains":
   - Add your specific WebContainer domain (e.g., `zp1v56uxy8rdx5ypatb0ockcb9tr6a.webcontainer.io`)
   - Add `localhost` for local development
   - Add your production domains

4. Under "Platform" > "Website":
   - Click "Add Platform" if Website is not listed
   - Add your Site URL:
     * Your specific WebContainer URL (e.g., `https://zp1v56uxy8rdx5ypatb0ockcb9tr6a.webcontainer.io`)
     * `http://localhost:5173` for local development
     * Your production URLs

5. Go to "Facebook Login" > "Settings":
   - Enable "Client OAuth Login"
   - Enable "Web OAuth Login"
   - Add your OAuth redirect URIs:
     * `https://zp1v56uxy8rdx5ypatb0ockcb9tr6a.webcontainer.io/auth/facebook/callback`
     * `http://localhost:5173/auth/facebook/callback`
   - Under "Allowed Domains for the JavaScript SDK", add:
     * Your specific WebContainer domain (e.g., `zp1v56uxy8rdx5ypatb0ockcb9tr6a.webcontainer.io`)
     * `localhost`
   - Set "Login with JavaScript SDK" to "Yes"

6. Under "App Review":
   - Submit your app for review to get the required permissions
   - For development, you can test with admin/developer accounts without review

7. Important Settings:
   - Make sure your app is in "Development Mode" for testing
   - Add all test users/developers in "Roles" section
   - Configure "OAuth Security" settings if needed

8. WebContainer-Specific Notes:
   - Each WebContainer instance gets a unique subdomain
   - You'll need to update the allowed domains in your Facebook App settings when testing in a new WebContainer instance
   - For development purposes, you can use the test users feature without submitting for app review

Remember to update your .env file with the correct App ID and Secret.