#!/bin/bash

# Create necessary directories
mkdir -p \
  src/components/analytics \
  src/components/auth \
  src/components/common \
  src/components/forms \
  src/components/layout \
  src/components/modals \
  src/components/posts \
  src/features/analytics \
  src/features/auth \
  src/features/notifications \
  src/features/posts \
  src/features/scheduling \
  src/features/teams \
  src/hooks \
  src/lib/api \
  src/lib/utils \
  src/pages \
  src/store \
  src/types \
  public/assets \
  nginx/conf.d \
  nginx/ssl \
  docker/development \
  docker/production

# Set up environment variables
cp .env.example .env

# Install dependencies
npm install

# Initialize Firebase
firebase init

# Set up Git hooks
npx husky install

echo "Setup completed successfully!"