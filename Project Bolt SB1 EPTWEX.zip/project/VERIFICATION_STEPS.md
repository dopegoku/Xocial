## OAuth Consent Screen Setup

1. External User Type
   - Select "External" 
   - Click "Create"

2. App Information
   - App name: "PostIT"
   - User support email: Your email
   - Developer contact email: Your email

3. App Domain
   - Add your WebContainer domain:
   `https://zp1v56uxy8rdx5ypatb0ockcb9tr6a-oci3--5173--f565b097.local-credentialless.webcontainer.io`

4. Authorized Domains
   - Add `webcontainer.io`

5. Scopes
   Add these scopes:
   - `https://www.googleapis.com/auth/youtube.readonly`
   - `https://www.googleapis.com/auth/youtube.upload`
   - `https://www.googleapis.com/auth/youtube.force-ssl`

6. Test Users
   - Add your Google account email as a test user
   - This allows you to test the app while in testing mode

## Required Verification Steps

1. Brand Verification
   - Go to "OAuth consent screen"
   - Click "Verify Domain"
   - Follow the verification process for webcontainer.io

2. Submit for Verification
   - Complete the questionnaire
   - Provide detailed justification for each scope
   - Include test account credentials
   - Add setup/testing instructions
   - Submit screenshots of OAuth implementation

3. Required Documentation
   - Privacy Policy URL
   - Terms of Service URL
   - YouTube Data API usage description
   - Implementation screenshots
   - Testing instructions

## Temporary Development Solution

While waiting for verification:
1. Keep app in "Testing" mode
2. Add your Google account as test user
3. Use test credentials:
   ```
   Client ID: 583501416530-bernc59uosa1q1muqilisbpvkjo0l05r.apps.googleusercontent.com
   Client Secret: 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
   ```

4. Ensure redirect URI matches exactly:
   ```
   https://zp1v56uxy8rdx5ypatb0ockcb9tr6a-oci3--5173--f565b097.local-credentialless.webcontainer.io/auth/youtube/callback
   ```