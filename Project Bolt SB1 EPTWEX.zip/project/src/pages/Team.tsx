import React from 'react';
import { UserPlus, Mail, Shield } from 'lucide-react';

const teamMembers = [
  {
    id: '1',
    name: 'John Doe',
    email: 'john@postit.com',
    role: 'Admin',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80',
  },
  {
    id: '2',
    name: 'Jane Smith',
    email: 'jane@postit.com',
    role: 'Editor',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80',
  },
];

export default function Team() {
  return (
    <div className="max-w-6xl mx-auto">
      <div className="flex justify-between items-center mb-8">
        <h2 className="text-2xl font-bold">Team Members</h2>
        <button className="btn btn-primary flex items-center space-x-2">
          <UserPlus className="w-5 h-5" />
          <span>Invite Member</span>
        </button>
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-xl overflow-hidden">
        <div className="divide-y divide-gray-200 dark:divide-gray-700">
          {teamMembers.map((member) => (
            <div key={member.id} className="p-6 flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <img
                  src={member.avatar}
                  alt={member.name}
                  className="w-12 h-12 rounded-full"
                />
                <div>
                  <h3 className="font-medium">{member.name}</h3>
                  <div className="flex items-center space-x-2 text-sm text-gray-500 dark:text-gray-400">
                    <Mail className="w-4 h-4" />
                    <span>{member.email}</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center space-x-4">
                <span className="flex items-center space-x-1 px-3 py-1 bg-purple-100 dark:bg-purple-900/50 text-purple-600 dark:text-purple-400 rounded-full text-sm">
                  <Shield className="w-4 h-4" />
                  <span>{member.role}</span>
                </span>
                <button className="btn btn-secondary">Manage</button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}