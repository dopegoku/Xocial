import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardContent } from '../components/ui/Card';
import { Tabs, Tab } from '../components/ui/Tabs';
import Button from '../components/ui/Button';
import { useSocialAccountsStore } from '../store/useSocialAccountsStore';
import { fetchYouTubeAnalytics } from '../lib/api/youtube';
import { fetchFacebookAnalytics } from '../lib/api/facebook';
import EngagementChart from '../components/analytics/EngagementChart';
import MetricsGrid from '../components/analytics/MetricsGrid';
import PerformanceChart from '../components/analytics/PerformanceChart';
import ComparisonChart from '../components/analytics/ComparisonChart';
import { Calendar, Download, Filter, Loader2 } from 'lucide-react';
import toast from 'react-hot-toast';
import type { SocialPlatform } from '../types';

export default function Analytics() {
  const { accounts } = useSocialAccountsStore();
  const [selectedPlatform, setSelectedPlatform] = useState<SocialPlatform | 'all'>('all');
  const [dateRange, setDateRange] = useState('7d');
  const [isLoading, setIsLoading] = useState(true);
  const [analyticsData, setAnalyticsData] = useState<any>({});

  useEffect(() => {
    const fetchAnalytics = async () => {
      setIsLoading(true);
      try {
        const data: any = {};

        // Fetch YouTube analytics if connected
        const youtubeAccount = accounts.find(acc => acc.platform === 'youtube');
        if (youtubeAccount) {
          data.youtube = await fetchYouTubeAnalytics();
        }

        // Fetch Facebook analytics if connected
        const facebookAccount = accounts.find(acc => acc.platform === 'facebook');
        if (facebookAccount) {
          data.facebook = await fetchFacebookAnalytics(
            facebookAccount.id,
            facebookAccount.accessToken
          );
        }

        setAnalyticsData(data);
      } catch (error) {
        console.error('Error fetching analytics:', error);
        toast.error('Failed to fetch analytics data');
      } finally {
        setIsLoading(false);
      }
    };

    fetchAnalytics();
  }, [accounts]);

  const platformTabs = [
    { value: 'all', label: 'All Platforms' },
    ...accounts.map(account => ({
      value: account.platform,
      label: account.platform.charAt(0).toUpperCase() + account.platform.slice(1)
    }))
  ];

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <Loader2 className="w-8 h-8 animate-spin text-purple-500" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Analytics</h2>
          <p className="text-gray-600 dark:text-gray-400">
            Track your social media performance
          </p>
        </div>
        <div className="flex space-x-3">
          <Button variant="secondary">
            <Filter className="w-4 h-4 mr-2" />
            Filter
          </Button>
          <Button variant="secondary">
            <Calendar className="w-4 h-4 mr-2" />
            Date Range
          </Button>
          <Button variant="secondary">
            <Download className="w-4 h-4 mr-2" />
            Export
          </Button>
        </div>
      </div>

      <Card>
        <CardContent className="p-6">
          <Tabs value={selectedPlatform} onChange={setSelectedPlatform as any}>
            {platformTabs.map(tab => (
              <Tab key={tab.value} value={tab.value}>{tab.label}</Tab>
            ))}
          </Tabs>
        </CardContent>
      </Card>

      {accounts.map(account => (
        (selectedPlatform === 'all' || selectedPlatform === account.platform) && (
          <div key={account.id} className="space-y-6">
            <Card>
              <CardHeader>
                <h3 className="text-xl font-semibold capitalize">
                  {account.platform} Overview
                </h3>
              </CardHeader>
              <CardContent>
                <MetricsGrid
                  platform={account.platform}
                  metrics={account.metrics}
                />
              </CardContent>
            </Card>

            {analyticsData[account.platform] && (
              <>
                <div className="grid md:grid-cols-2 gap-6">
                  <Card>
                    <CardHeader>
                      <h3 className="text-lg font-semibold">Engagement Rate</h3>
                    </CardHeader>
                    <CardContent>
                      <EngagementChart
                        platform={account.platform}
                        data={[4.2, 4.5, 4.1, 4.8, 4.3, 4.6, 4.5]} // Replace with actual data
                      />
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <h3 className="text-lg font-semibold">Performance</h3>
                    </CardHeader>
                    <CardContent>
                      <PerformanceChart
                        platform={account.platform}
                        data={{
                          labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
                          values: [1200, 1900, 1500, 2100, 2400, 1800, 2800]
                        }}
                        title="Daily Views"
                      />
                    </CardContent>
                  </Card>
                </div>

                <Card>
                  <CardHeader>
                    <h3 className="text-lg font-semibold">Recent Content Performance</h3>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {/* Render platform-specific content performance */}
                      {account.platform === 'youtube' && analyticsData.youtube?.recentVideos?.map((video: any) => (
                        <div key={video.id} className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg">
                          <img
                            src={video.snippet.thumbnails.medium.url}
                            alt={video.snippet.title}
                            className="w-full rounded-lg mb-2"
                          />
                          <h4 className="font-medium truncate">{video.snippet.title}</h4>
                          <div className="text-sm text-gray-500">
                            <p>Views: {video.statistics?.viewCount || 0}</p>
                            <p>Likes: {video.statistics?.likeCount || 0}</p>
                          </div>
                        </div>
                      ))}
                      {account.platform === 'facebook' && analyticsData.facebook?.recentPosts?.map((post: any) => (
                        <div key={post.id} className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg">
                          <p className="font-medium mb-2 line-clamp-2">{post.message}</p>
                          <div className="text-sm text-gray-500">
                            <p>Likes: {post.likes?.summary?.total_count || 0}</p>
                            <p>Comments: {post.comments?.summary?.total_count || 0}</p>
                            <p>Shares: {post.shares?.count || 0}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </>
            )}
          </div>
        )
      ))}
    </div>
  );
}