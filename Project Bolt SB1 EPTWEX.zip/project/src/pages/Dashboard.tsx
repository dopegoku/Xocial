import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { BarChart2, Users, TrendingUp, Calendar, Plus, Info, Youtube, Facebook, Instagram, Twitter } from 'lucide-react';
import { Card, CardHeader, CardContent } from '../components/ui/Card';
import Button from '../components/ui/Button';
import PlatformStatus from '../components/PlatformStatus';
import { useSocialAccountsStore } from '../store/useSocialAccountsStore';
import MetricsCard from '../components/MetricsCard';
import toast from 'react-hot-toast';

// Mock data for initial testing
const mockAnalytics = {
  youtube: {
    views: 150000,
    subscribers: 25000,
    engagement: 8.5,
    change: 12.3
  },
  facebook: {
    reach: 80000,
    followers: 35000,
    engagement: 4.2,
    change: 5.8
  }
};

export default function Dashboard() {
  const navigate = useNavigate();
  const { accounts } = useSocialAccountsStore();
  const [isLoading, setIsLoading] = useState(true);
  const [analytics, setAnalytics] = useState(mockAnalytics);

  useEffect(() => {
    const fetchAnalytics = async () => {
      try {
        // Fetch YouTube analytics if connected
        const youtubeAccount = accounts.find(acc => acc.platform === 'youtube');
        if (youtubeAccount) {
          // Implement YouTube analytics fetch
          // const youtubeData = await fetchYouTubeAnalytics();
          // setAnalytics(prev => ({ ...prev, youtube: youtubeData }));
        }

        // Fetch Facebook analytics if connected
        const facebookAccount = accounts.find(acc => acc.platform === 'facebook');
        if (facebookAccount) {
          // Implement Facebook analytics fetch
          // const facebookData = await fetchFacebookAnalytics();
          // setAnalytics(prev => ({ ...prev, facebook: facebookData }));
        }
      } catch (error) {
        console.error('Error fetching analytics:', error);
        toast.error('Failed to fetch analytics data');
      } finally {
        setIsLoading(false);
      }
    };

    fetchAnalytics();
  }, [accounts]);

  const platformIcons = {
    youtube: Youtube,
    facebook: Facebook,
    instagram: Instagram,
    twitter: Twitter
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Social Media Dashboard</h2>
          <p className="text-gray-600 dark:text-gray-400">
            Track your social media performance across platforms
          </p>
        </div>
        <Button onClick={() => navigate('/create-post')}>
          <Plus className="w-4 h-4 mr-2" />
          Create Post
        </Button>
      </div>

      {accounts.length === 0 ? (
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-3 text-blue-600 bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg">
              <Info className="w-6 h-6 flex-shrink-0" />
              <p>Connect your social media accounts to start seeing your analytics and metrics.</p>
            </div>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {accounts.map((account) => {
            const Icon = platformIcons[account.platform];
            return (
              <MetricsCard
                key={account.id}
                platform={account.platform}
                metrics={account.metrics}
                change={5.2} // Replace with actual change calculation
                icon={<Icon className="w-6 h-6 text-purple-500" />}
              />
            );
          })}
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <Card>
          <CardHeader>
            <h3 className="text-lg font-semibold">Quick Actions</h3>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
                {
                  icon: Calendar,
                  title: 'Schedule Posts',
                  description: 'Plan and schedule your content',
                  action: () => navigate('/schedule')
                },
                {
                  icon: BarChart2,
                  title: 'View Analytics',
                  description: 'Track performance metrics',
                  action: () => navigate('/analytics')
                },
                {
                  icon: Users,
                  title: 'Manage Team',
                  description: 'Add and manage team members',
                  action: () => navigate('/team')
                }
              ].map((action, index) => (
                <div
                  key={index}
                  onClick={action.action}
                  className="flex items-center space-x-3 p-3 bg-gray-50 dark:bg-gray-800 rounded-lg cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                >
                  <action.icon className="w-5 h-5 text-purple-500" />
                  <div>
                    <p className="font-medium">{action.title}</p>
                    <p className="text-sm text-gray-500">{action.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="md:col-span-2">
          <CardHeader>
            <h3 className="text-lg font-semibold">Recent Performance</h3>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {accounts.map((account) => (
                <div
                  key={account.id}
                  className="p-4 border border-gray-200 dark:border-gray-700 rounded-lg"
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      {platformIcons[account.platform] && (
                        <account.platform className="w-5 h-5" />
                      )}
                      <span className="font-medium capitalize">{account.platform}</span>
                    </div>
                    <span className="text-sm text-green-500">+{account.metrics.engagement}%</span>
                  </div>
                  <div className="grid grid-cols-3 gap-4">
                    <div>
                      <p className="text-sm text-gray-500">Reach</p>
                      <p className="font-semibold">{account.metrics.reach.toLocaleString()}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Engagement</p>
                      <p className="font-semibold">{account.metrics.engagement}%</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Posts</p>
                      <p className="font-semibold">{account.metrics.posts}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <PlatformStatus />
    </div>
  );
}