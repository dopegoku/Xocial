import React, { useState } from 'react';
import { Sparkles, Calendar, Hash } from 'lucide-react';
import { Card, CardHeader, CardContent } from '../components/ui/Card';
import Button from '../components/ui/Button';
import PlatformContentEditor, { PlatformContent } from '../features/content/PlatformContentEditor';
import type { SocialPlatform } from '../types';
import ContentGenerator from '../features/ai/ContentGenerator';
import HashtagAnalyzer from '../features/hashtags/HashtagAnalyzer';

export default function CreatePost() {
  const [selectedPlatforms, setSelectedPlatforms] = useState<SocialPlatform[]>(['instagram']);
  const [platformContent, setPlatformContent] = useState<Record<SocialPlatform, PlatformContent>>({
    instagram: { text: '', media: [], hashtags: [] },
    facebook: { text: '', media: [], hashtags: [] },
    twitter: { text: '', media: [], hashtags: [] },
    youtube: { text: '', media: [], hashtags: [] }
  });

  const handlePlatformSelect = (platform: SocialPlatform) => {
    setSelectedPlatforms(prev =>
      prev.includes(platform)
        ? prev.filter(p => p !== platform)
        : [...prev, platform]
    );
  };

  const handleContentChange = (platform: SocialPlatform, content: PlatformContent) => {
    setPlatformContent(prev => ({
      ...prev,
      [platform]: content
    }));
  };

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold mb-6">Create New Post</h2>
      </div>

      {/* Platform Selection */}
      <Card>
        <CardHeader>
          <h3 className="text-lg font-semibold">Select Platforms</h3>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-4">
            {(['instagram', 'facebook', 'twitter', 'youtube'] as const).map(platform => (
              <Button
                key={platform}
                variant={selectedPlatforms.includes(platform) ? 'primary' : 'secondary'}
                onClick={() => handlePlatformSelect(platform)}
                className="capitalize"
              >
                {platform}
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* AI Content Generator */}
      <ContentGenerator />

      {/* Platform-specific Content Editors */}
      {selectedPlatforms.map(platform => (
        <PlatformContentEditor
          key={platform}
          platform={platform}
          onContentChange={(content) => handleContentChange(platform, content)}
        />
      ))}

      {/* Hashtag Analyzer */}
      <HashtagAnalyzer />

      {/* Action Buttons */}
      <div className="flex justify-end space-x-4">
        <Button variant="secondary">
          <Calendar className="w-4 h-4 mr-2" />
          Schedule
        </Button>
        <Button>
          Publish Now
        </Button>
      </div>
    </div>
  );
}