import React, { useState } from 'react';
import { Instagram, Facebook, Twitter, Youtube, Plus, Settings2, Link2, AlertCircle } from 'lucide-react';
import { useSocialAccountsStore } from '../store/useSocialAccountsStore';
import ConnectAccountModal from '../components/modals/ConnectAccountModal';
import type { SocialPlatform } from '../types';

const platformConfig = {
  instagram: {
    name: 'Instagram',
    icon: Instagram,
    color: 'text-pink-600 dark:text-pink-400',
    bgColor: 'bg-pink-100 dark:bg-pink-900/50',
    borderColor: 'border-pink-200 dark:border-pink-800',
  },
  facebook: {
    name: 'Facebook',
    icon: Facebook,
    color: 'text-blue-600 dark:text-blue-400',
    bgColor: 'bg-blue-100 dark:bg-blue-900/50',
    borderColor: 'border-blue-200 dark:border-blue-800',
  },
  twitter: {
    name: 'Twitter',
    icon: Twitter,
    color: 'text-sky-600 dark:text-sky-400',
    bgColor: 'bg-sky-100 dark:bg-sky-900/50',
    borderColor: 'border-sky-200 dark:border-sky-800',
  },
  youtube: {
    name: 'YouTube',
    icon: Youtube,
    color: 'text-red-600 dark:text-red-400',
    bgColor: 'bg-red-100 dark:bg-red-900/50',
    borderColor: 'border-red-200 dark:border-red-800',
  },
};

export default function Accounts() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const { accounts } = useSocialAccountsStore();

  return (
    <div className="max-w-6xl mx-auto">
      <div className="flex justify-between items-center mb-8">
        <h2 className="text-2xl font-bold">Connected Accounts</h2>
        <button
          onClick={() => setIsModalOpen(true)}
          className="btn btn-primary flex items-center space-x-2"
        >
          <Plus className="w-5 h-5" />
          <span>Connect Account</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {Object.entries(platformConfig).map(([platform, config]) => {
          const account = accounts.find(acc => acc.platform === platform);
          const Icon = config.icon;

          return (
            <div
              key={platform}
              className={`border ${config.borderColor} rounded-xl overflow-hidden`}
            >
              <div className={`${config.bgColor} p-6`}>
                <div className="flex items-center justify-between mb-4">
                  <Icon className={`w-8 h-8 ${config.color}`} />
                  {account ? (
                    <button className="p-2 hover:bg-white/10 rounded-full">
                      <Settings2 className="w-5 h-5" />
                    </button>
                  ) : null}
                </div>
                <h3 className="text-lg font-semibold">{config.name}</h3>
                {account ? (
                  <div className="mt-2">
                    <p className="text-sm text-gray-600 dark:text-gray-400">{account.username}</p>
                    <div className="flex items-center space-x-1 mt-1">
                      <div className="w-2 h-2 bg-green-500 rounded-full" />
                      <span className="text-sm text-gray-600 dark:text-gray-400">Connected</span>
                    </div>
                  </div>
                ) : (
                  <button
                    onClick={() => setIsModalOpen(true)}
                    className="mt-4 flex items-center space-x-2 text-sm font-medium"
                  >
                    <Link2 className="w-4 h-4" />
                    <span>Connect {config.name}</span>
                  </button>
                )}
              </div>
              {account && (
                <div className="p-4 bg-white dark:bg-gray-800">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-gray-500 dark:text-gray-400">Followers</p>
                      <p className="font-semibold">{account.metrics.reach.toLocaleString()}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500 dark:text-gray-400">Engagement</p>
                      <p className="font-semibold">{account.metrics.engagement}%</p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      <ConnectAccountModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSuccess={() => setIsModalOpen(false)}
      />
    </div>
  );
}