import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardContent } from '../components/ui/Card';
import Button from '../components/ui/Button';
import { useFacebookAuth } from '../hooks/useFacebookAuth';
import { Loader2, Facebook, BarChart2, Info } from 'lucide-react';
import { getPageInsights } from '../lib/api/facebook';
import toast from 'react-hot-toast';
import config from '../config/facebook';

export default function FacebookTest() {
  const { authenticate, isAuthenticating } = useFacebookAuth();
  const [pageData, setPageData] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Get WebContainer information
  const webContainerId = window.location.hostname.split('.')[0];
  const fullDomain = window.location.origin;
  const callbackUrl = `${fullDomain}/auth/facebook/callback`;

  const handleConnect = async () => {
    try {
      await authenticate();
      toast.success('Facebook connected successfully!');
    } catch (error) {
      console.error('Connection error:', error);
      toast.error('Failed to connect Facebook');
    }
  };

  const fetchPageData = async () => {
    setIsLoading(true);
    try {
      const accessToken = localStorage.getItem('facebook_access_token');
      if (!accessToken) {
        throw new Error('No access token found');
      }

      const response = await fetch(
        `https://graph.facebook.com/v19.0/me/accounts?access_token=${accessToken}`
      );

      if (!response.ok) {
        throw new Error('Failed to fetch pages');
      }

      const data = await response.json();
      const page = data.data[0];

      if (page) {
        const insights = await getPageInsights(page.id, page.access_token);
        setPageData({ page, insights });
        toast.success('Page data fetched successfully!');
      } else {
        toast.error('No Facebook pages found');
      }
    } catch (error) {
      console.error('Fetch error:', error);
      toast.error('Failed to fetch page data');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <Card>
        <CardHeader>
          <h2 className="text-2xl font-bold">Facebook API Test</h2>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Display WebContainer Information */}
          <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg space-y-2">
            <div className="flex items-center space-x-2">
              <Info className="w-5 h-5 text-blue-500" />
              <h3 className="font-semibold">WebContainer Information</h3>
            </div>
            <div className="space-y-1 text-sm">
              <p><span className="font-medium">WebContainer ID:</span> {webContainerId}</p>
              <p><span className="font-medium">Full Domain:</span> {fullDomain}</p>
              <p><span className="font-medium">Callback URL:</span> {callbackUrl}</p>
            </div>
            <div className="mt-4 text-sm text-blue-600">
              Add these URLs to your Facebook App Settings:
              <ul className="list-disc list-inside mt-2 space-y-1">
                <li>Add <code>{fullDomain}</code> under App Domains</li>
                <li>Add <code>{callbackUrl}</code> under Valid OAuth Redirect URIs</li>
              </ul>
            </div>
          </div>

          <div className="flex space-x-4">
            <Button
              onClick={handleConnect}
              disabled={isAuthenticating}
            >
              {isAuthenticating ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Connecting...
                </>
              ) : (
                <>
                  <Facebook className="w-4 h-4 mr-2" />
                  Connect Facebook Account
                </>
              )}
            </Button>

            <Button
              onClick={fetchPageData}
              disabled={isLoading || !localStorage.getItem('facebook_access_token')}
              variant="secondary"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Loading...
                </>
              ) : (
                <>
                  <BarChart2 className="w-4 h-4 mr-2" />
                  Fetch Page Data
                </>
              )}
            </Button>
          </div>

          {pageData && (
            <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-4">
              <h3 className="font-semibold mb-4">Page Information:</h3>
              <pre className="whitespace-pre-wrap overflow-auto">
                {JSON.stringify(pageData, null, 2)}
              </pre>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}