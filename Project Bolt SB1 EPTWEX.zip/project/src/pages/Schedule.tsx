import React, { useState } from 'react';
import { Calendar as CalendarIcon, Plus, Filter, Search } from 'lucide-react';
import { Card, CardHeader, CardContent } from '../components/ui/Card';
import Button from '../components/ui/Button';
import Input from '../components/ui/Input';
import { format, addDays, isSameDay } from 'date-fns';

interface ScheduledPost {
  id: string;
  content: string;
  platforms: string[];
  scheduledFor: Date;
  status: 'scheduled' | 'draft' | 'published' | 'failed';
  media?: string[];
}

export default function Schedule() {
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [searchTerm, setSearchTerm] = useState('');
  const [filterPlatform, setFilterPlatform] = useState<string | null>(null);

  const scheduledPosts: ScheduledPost[] = [
    {
      id: '1',
      content: 'Check out our latest product launch! 🚀',
      platforms: ['instagram', 'facebook'],
      scheduledFor: addDays(new Date(), 1),
      status: 'scheduled',
      media: ['https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=300&h=300&fit=crop']
    },
    {
      id: '2',
      content: 'Join us for a live Q&A session next week',
      platforms: ['youtube', 'twitter'],
      scheduledFor: addDays(new Date(), 2),
      status: 'draft'
    },
    {
      id: '3',
      content: 'Behind the scenes look at our team',
      platforms: ['instagram'],
      scheduledFor: new Date(),
      status: 'published',
      media: ['https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=300&h=300&fit=crop']
    }
  ];

  const filteredPosts = scheduledPosts.filter(post => {
    const matchesSearch = post.content.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesPlatform = !filterPlatform || post.platforms.includes(filterPlatform);
    return matchesSearch && matchesPlatform;
  });

  const nextSevenDays = Array.from({ length: 7 }, (_, i) => addDays(new Date(), i));

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Content Calendar</h2>
        <Button>
          <Plus className="w-4 h-4 mr-2" />
          Schedule New Post
        </Button>
      </div>

      <div className="flex space-x-4 overflow-x-auto pb-4">
        {nextSevenDays.map((date) => (
          <button
            key={date.toISOString()}
            onClick={() => setSelectedDate(date)}
            className={`flex flex-col items-center min-w-[100px] p-3 rounded-lg border ${
              isSameDay(selectedDate, date)
                ? 'border-purple-500 bg-purple-50 dark:bg-purple-900/20'
                : 'border-gray-200 dark:border-gray-700'
            }`}
          >
            <span className="text-sm font-medium">{format(date, 'EEE')}</span>
            <span className="text-2xl font-bold my-1">{format(date, 'd')}</span>
            <span className="text-sm text-gray-500">{format(date, 'MMM')}</span>
          </button>
        ))}
      </div>

      <div className="flex space-x-4 mb-6">
        <div className="flex-1">
          <Input
            placeholder="Search scheduled posts..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            leftIcon={<Search className="w-4 h-4" />}
          />
        </div>
        <Button variant="secondary">
          <Filter className="w-4 h-4 mr-2" />
          Filter
        </Button>
      </div>

      <div className="space-y-4">
        {filteredPosts.map((post) => (
          <Card key={post.id}>
            <CardContent className="p-6">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <p className="text-lg font-medium mb-2">{post.content}</p>
                  <div className="flex space-x-2">
                    {post.platforms.map((platform) => (
                      <span
                        key={platform}
                        className="px-3 py-1 bg-purple-100 dark:bg-purple-900/50 text-purple-600 dark:text-purple-400 rounded-full text-sm"
                      >
                        {platform}
                      </span>
                    ))}
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-sm text-gray-500 dark:text-gray-400">Scheduled for</p>
                  <p className="font-medium">{format(post.scheduledFor, 'PPp')}</p>
                  <span className={`inline-block px-2 py-1 rounded-full text-xs mt-2 ${
                    post.status === 'published' ? 'bg-green-100 text-green-600' :
                    post.status === 'scheduled' ? 'bg-blue-100 text-blue-600' :
                    post.status === 'draft' ? 'bg-gray-100 text-gray-600' :
                    'bg-red-100 text-red-600'
                  }`}>
                    {post.status.charAt(0).toUpperCase() + post.status.slice(1)}
                  </span>
                </div>
              </div>

              {post.media && (
                <div className="mt-4 grid grid-cols-2 gap-4">
                  {post.media.map((url, index) => (
                    <img
                      key={index}
                      src={url}
                      alt={`Post media ${index + 1}`}
                      className="rounded-lg w-full h-48 object-cover"
                    />
                  ))}
                </div>
              )}
              
              <div className="flex space-x-3 mt-4">
                <Button variant="secondary">Edit</Button>
                <Button variant="secondary" className="text-red-600">Delete</Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}