import React, { useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';

export default function GoogleCallback() {
  const [searchParams] = useSearchParams();

  useEffect(() => {
    const code = searchParams.get('code');
    const state = searchParams.get('state');
    const error = searchParams.get('error');

    if (code && state) {
      // Send message to opener window
      window.opener?.postMessage(
        {
          type: 'GOOGLE_OAUTH_SUCCESS',
          code,
          state
        },
        window.location.origin
      );
    } else if (error) {
      window.opener?.postMessage(
        {
          type: 'GOOGLE_OAUTH_ERROR',
          error
        },
        window.location.origin
      );
    }

    // Close the popup after a short delay
    setTimeout(() => window.close(), 1000);
  }, [searchParams]);

  return (
    <div className="min-h-screen flex items-center justify-center">
      <p className="text-lg">Completing authentication...</p>
    </div>
  );
}