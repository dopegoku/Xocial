import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Github } from 'lucide-react';
import { Card, CardHeader, CardContent } from '../../components/ui/Card';
import Button from '../../components/ui/Button';
import Input from '../../components/ui/Input';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useAuthStore } from '../../store/useAuthStore';
import { signInWithProvider, signInWithEmailPassword } from '../../lib/api/auth';
import toast from 'react-hot-toast';
import config from '../../config/google';

const signInSchema = z.object({
  email: z.string().email('Invalid email address'),
  password: z.string().min(6, 'Password must be at least 6 characters'),
});

type SignInFormData = z.infer<typeof signInSchema>;

export default function SignIn() {
  const navigate = useNavigate();
  const { login } = useAuthStore();
  const { register, handleSubmit, formState: { errors } } = useForm<SignInFormData>({
    resolver: zodResolver(signInSchema),
  });

  const handleGoogleSignIn = async () => {
    try {
      // Generate state parameter
      const state = Math.random().toString(36).substring(7);
      sessionStorage.setItem('google_auth_state', state);

      // Construct auth URL
      const params = new URLSearchParams({
        client_id: config.clientId,
        redirect_uri: config.redirectUri,
        response_type: 'code',
        scope: config.scope,
        access_type: 'offline',
        state: state,
        prompt: 'consent'
      });

      const authUrl = `https://accounts.google.com/o/oauth2/v2/auth?${params.toString()}`;
      
      // Open popup
      const popup = window.open(
        authUrl,
        'Google OAuth',
        'width=600,height=700,left=200,top=100'
      );

      if (!popup) {
        throw new Error('Popup blocked. Please allow popups for this site.');
      }

      // Handle the OAuth response
      const result = await new Promise((resolve, reject) => {
        const handleMessage = async (event: MessageEvent) => {
          if (event.origin !== window.location.origin) return;

          if (event.data.type === 'GOOGLE_OAUTH_SUCCESS') {
            try {
              const user = await signInWithProvider('google', event.data.code);
              resolve(user);
            } catch (error) {
              reject(error);
            }
          } else if (event.data.type === 'GOOGLE_OAUTH_ERROR') {
            reject(new Error(event.data.error));
          }
        };

        window.addEventListener('message', handleMessage);
        popup.addEventListener('close', () => {
          window.removeEventListener('message', handleMessage);
        });
      });

      login(result as any);
      toast.success('Successfully signed in with Google!');
      navigate('/');
    } catch (error) {
      console.error('Google Sign In Error:', error);
      toast.error('Failed to sign in with Google');
    }
  };

  const handleGithubSignIn = async () => {
    try {
      const user = await signInWithProvider('github');
      login(user);
      toast.success('Successfully signed in with GitHub!');
      navigate('/');
    } catch (error) {
      toast.error('Failed to sign in with GitHub');
    }
  };

  const onSubmit = async (data: SignInFormData) => {
    try {
      const user = await signInWithEmailPassword(data.email, data.password);
      login(user);
      toast.success('Successfully signed in!');
      navigate('/');
    } catch (error) {
      toast.error('Invalid email or password');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-900 px-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <div className="text-center">
            <h1 className="text-2xl font-bold">Welcome back to PostIT</h1>
            <p className="text-gray-600 dark:text-gray-400 mt-2">
              Sign in to your account to continue
            </p>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <Button
              onClick={handleGoogleSignIn}
              variant="secondary"
              className="w-full"
            >
              <img
                src="https://www.google.com/favicon.ico"
                alt="Google"
                className="w-5 h-5 mr-2"
              />
              Continue with Google
            </Button>
            
            <Button
              onClick={handleGithubSignIn}
              variant="secondary"
              className="w-full"
            >
              <Github className="w-5 h-5 mr-2" />
              Continue with GitHub
            </Button>

            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <span className="w-full border-t border-gray-300 dark:border-gray-600" />
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="px-2 bg-white dark:bg-gray-800 text-gray-500">
                  Or continue with
                </span>
              </div>
            </div>

            <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
              <Input
                label="Email"
                type="email"
                {...register('email')}
                error={errors.email?.message}
              />
              <Input
                label="Password"
                type="password"
                {...register('password')}
                error={errors.password?.message}
              />

              <Button type="submit" className="w-full">
                Sign in with Email
              </Button>
            </form>

            <p className="text-center text-sm text-gray-600 dark:text-gray-400">
              Don't have an account?{' '}
              <button
                onClick={() => navigate('/signup')}
                className="text-purple-600 hover:text-purple-500"
              >
                Sign up
              </button>
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}