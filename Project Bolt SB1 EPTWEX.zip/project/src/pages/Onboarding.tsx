import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardHeader, CardContent } from '../components/ui/Card';
import Button from '../components/ui/Button';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useAuthStore } from '../store/useAuthStore';
import { updateUserProfile } from '../lib/api/auth';
import toast from 'react-hot-toast';

const accountTypes = [
  {
    id: 'influencer',
    title: 'Influencer',
    description: 'Personal brand or content creator',
    icon: '👤',
  },
  {
    id: 'startup',
    title: 'Startup',
    description: 'Small to medium-sized business',
    icon: '🚀',
  },
  {
    id: 'agency',
    title: 'Marketing Agency',
    description: 'Digital marketing or social media agency',
    icon: '🏢',
  },
  {
    id: 'enterprise',
    title: 'Enterprise',
    description: 'Large organization or corporation',
    icon: '🌐',
  },
];

const industries = [
  'Technology',
  'E-commerce',
  'Fashion & Beauty',
  'Food & Beverage',
  'Health & Wellness',
  'Education',
  'Entertainment',
  'Finance',
  'Travel',
  'Other',
];

const onboardingSchema = z.object({
  accountType: z.enum(['influencer', 'startup', 'agency', 'enterprise']),
  industry: z.string().min(1, 'Please select an industry'),
  teamSize: z.number().min(1),
  goals: z.array(z.string()).min(1, 'Please select at least one goal'),
});

type OnboardingFormData = z.infer<typeof onboardingSchema>;

export default function Onboarding() {
  const navigate = useNavigate();
  const { user, updateUser } = useAuthStore();
  const [step, setStep] = useState(1);

  const { register, handleSubmit, watch, setValue, formState: { errors } } = useForm<OnboardingFormData>({
    resolver: zodResolver(onboardingSchema),
    defaultValues: {
      goals: [],
    },
  });

  const selectedAccountType = watch('accountType');

  const onSubmit = async (data: OnboardingFormData) => {
    try {
      await updateUserProfile(user!.id, {
        ...user,
        accountType: data.accountType,
        industry: data.industry,
        teamSize: data.teamSize,
        goals: data.goals,
        onboardingCompleted: true,
      });
      
      updateUser({
        ...user!,
        accountType: data.accountType,
        onboardingCompleted: true,
      });

      toast.success('Profile setup completed!');
      navigate('/');
    } catch (error) {
      toast.error('Failed to save profile. Please try again.');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-900 px-4">
      <Card className="w-full max-w-2xl">
        <CardHeader>
          <div className="text-center">
            <h1 className="text-2xl font-bold">Welcome to PostIT</h1>
            <p className="text-gray-600 dark:text-gray-400 mt-2">
              Let's set up your account to get started
            </p>
          </div>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
            {step === 1 && (
              <div className="space-y-4">
                <h2 className="text-lg font-semibold">What best describes you?</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {accountTypes.map((type) => (
                    <button
                      key={type.id}
                      type="button"
                      onClick={() => setValue('accountType', type.id as any)}
                      className={`p-4 rounded-lg border text-left transition-colors ${
                        selectedAccountType === type.id
                          ? 'border-purple-500 bg-purple-50 dark:bg-purple-900/20'
                          : 'border-gray-200 dark:border-gray-700 hover:border-purple-500'
                      }`}
                    >
                      <span className="text-2xl mb-2 block">{type.icon}</span>
                      <h3 className="font-medium">{type.title}</h3>
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        {type.description}
                      </p>
                    </button>
                  ))}
                </div>
                {errors.accountType && (
                  <p className="text-sm text-red-500">{errors.accountType.message}</p>
                )}
                <Button
                  type="button"
                  onClick={() => setStep(2)}
                  disabled={!selectedAccountType}
                  className="w-full mt-6"
                >
                  Continue
                </Button>
              </div>
            )}

            {step === 2 && (
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-medium mb-2">
                    Select your industry
                  </label>
                  <select
                    {...register('industry')}
                    className="w-full rounded-md border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 p-2"
                  >
                    <option value="">Select an industry</option>
                    {industries.map((industry) => (
                      <option key={industry} value={industry}>
                        {industry}
                      </option>
                    ))}
                  </select>
                  {errors.industry && (
                    <p className="text-sm text-red-500 mt-1">{errors.industry.message}</p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">
                    Team size
                  </label>
                  <input
                    type="number"
                    {...register('teamSize', { valueAsNumber: true })}
                    className="w-full rounded-md border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 p-2"
                    min="1"
                  />
                  {errors.teamSize && (
                    <p className="text-sm text-red-500 mt-1">{errors.teamSize.message}</p>
                  )}
                </div>

                <div className="flex justify-between space-x-4">
                  <Button
                    type="button"
                    variant="secondary"
                    onClick={() => setStep(1)}
                  >
                    Back
                  </Button>
                  <Button type="submit">
                    Complete Setup
                  </Button>
                </div>
              </div>
            )}
          </form>
        </CardContent>
      </Card>
    </div>
  );
}