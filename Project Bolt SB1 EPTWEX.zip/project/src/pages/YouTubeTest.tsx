import React, { useState } from 'react';
import { Card, CardHeader, CardContent } from '../components/ui/Card';
import Button from '../components/ui/Button';
import { useYouTubeAuth } from '../hooks/useYouTubeAuth';
import { Loader2, Video, BarChart2 } from 'lucide-react';
import config from '../config/google';

export default function YouTubeTest() {
  const { authenticate, isAuthenticating } = useYouTubeAuth();
  const [channelData, setChannelData] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleConnect = async () => {
    try {
      await authenticate();
    } catch (error) {
      console.error('Connection error:', error);
    }
  };

  const fetchChannelData = async () => {
    setIsLoading(true);
    try {
      const accessToken = localStorage.getItem('youtube_access_token');
      if (!accessToken) {
        throw new Error('No access token found');
      }

      const response = await fetch(
        'https://www.googleapis.com/youtube/v3/channels?part=snippet,statistics&mine=true',
        {
          headers: {
            'Authorization': `Bearer ${accessToken}`
          }
        }
      );

      if (!response.ok) {
        throw new Error('Failed to fetch channel data');
      }

      const data = await response.json();
      setChannelData(data.items?.[0]);
    } catch (error) {
      console.error('Fetch error:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <Card>
        <CardHeader>
          <h2 className="text-2xl font-bold">YouTube API Test</h2>
          <p className="text-sm text-gray-500">Current redirect URI: {config.redirectUri}</p>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex space-x-4">
            <Button
              onClick={handleConnect}
              disabled={isAuthenticating}
            >
              {isAuthenticating ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Connecting...
                </>
              ) : (
                <>
                  <Video className="w-4 h-4 mr-2" />
                  Connect YouTube Account
                </>
              )}
            </Button>

            <Button
              onClick={fetchChannelData}
              disabled={isLoading || !localStorage.getItem('youtube_access_token')}
              variant="secondary"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Loading...
                </>
              ) : (
                <>
                  <BarChart2 className="w-4 h-4 mr-2" />
                  Fetch Channel Data
                </>
              )}
            </Button>
          </div>

          {channelData && (
            <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-4">
              <h3 className="font-semibold mb-4">Channel Information:</h3>
              <pre className="whitespace-pre-wrap overflow-auto">
                {JSON.stringify(channelData, null, 2)}
              </pre>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}