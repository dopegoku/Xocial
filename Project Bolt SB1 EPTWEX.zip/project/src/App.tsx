import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import Layout from './components/Layout';
import Dashboard from './pages/Dashboard';
import Schedule from './pages/Schedule';
import Analytics from './pages/Analytics';
import Team from './pages/Team';
import Settings from './pages/Settings';
import CreatePost from './pages/CreatePost';
import YouTubeTest from './pages/YouTubeTest';
import FacebookTest from './pages/FacebookTest';
import GoogleCallback from './pages/auth/GoogleCallback';
import SignIn from './pages/auth/SignIn';
import SignUp from './pages/auth/SignUp';
import Onboarding from './pages/Onboarding';
import { useAuthStore } from './store/useAuthStore';

// Mock user for development
const mockUser = {
  id: '1',
  name: 'Demo User',
  email: 'demo@example.com',
  avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80',
  theme: 'light',
  accounts: [],
  onboardingCompleted: true,
  accountType: 'agency',
  industry: 'Technology',
  teamSize: 5,
  goals: ['increase_engagement', 'grow_audience']
};

export default function App() {
  const { login } = useAuthStore();

  // Auto login with mock user
  React.useEffect(() => {
    login(mockUser);
  }, [login]);

  return (
    <>
      <Toaster position="top-right" />
      <Routes>
        <Route element={<Layout />}>
          <Route path="/" element={<Dashboard />} />
          <Route path="/schedule" element={<Schedule />} />
          <Route path="/analytics" element={<Analytics />} />
          <Route path="/team" element={<Team />} />
          <Route path="/settings" element={<Settings />} />
          <Route path="/create-post" element={<CreatePost />} />
          <Route path="/youtube-test" element={<YouTubeTest />} />
          <Route path="/facebook-test" element={<FacebookTest />} />
        </Route>
        <Route path="/auth/youtube/callback" element={<GoogleCallback />} />
        <Route path="/signin" element={<SignIn />} />
        <Route path="/signup" element={<SignUp />} />
        <Route path="/onboarding" element={<Onboarding />} />
      </Routes>
    </>
  );
}