import { useState, useCallback } from 'react';
import { initFacebookSDK, handleFacebookLogin, getLongLivedToken } from '../lib/api/facebook';
import { useNotificationStore } from '../store/useNotificationStore';
import toast from 'react-hot-toast';

export function useFacebookAuth() {
  const [isAuthenticating, setIsAuthenticating] = useState(false);
  const addNotification = useNotificationStore(state => state.addNotification);

  const authenticate = useCallback(async () => {
    setIsAuthenticating(true);
    try {
      // Initialize Facebook SDK first
      await initFacebookSDK();
      
      // Handle Facebook Login
      const authResponse = await handleFacebookLogin();
      
      if (authResponse?.accessToken) {
        // Get long-lived access token
        const longLivedToken = await getLongLivedToken(authResponse.accessToken);
        
        // Store the token
        localStorage.setItem('facebook_access_token', longLivedToken);

        addNotification({
          type: 'success',
          title: 'Facebook Connected',
          message: 'Successfully connected Facebook account and pages',
          platform: 'facebook'
        });

        return authResponse;
      }
    } catch (error) {
      console.error('Facebook Auth Error:', error);
      toast.error('Failed to connect Facebook account');
      addNotification({
        type: 'error',
        title: 'Connection Failed',
        message: 'Failed to connect Facebook account. Please try again.',
        platform: 'facebook'
      });
      throw error;
    } finally {
      setIsAuthenticating(false);
    }
  }, [addNotification]);

  return {
    authenticate,
    isAuthenticating
  };
}