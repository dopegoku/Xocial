import { useState, useCallback } from 'react';
import config from '../config/google';
import { useNotificationStore } from '../store/useNotificationStore';
import { useSocialAccountsStore } from '../store/useSocialAccountsStore';
import toast from 'react-hot-toast';
import axios from 'axios';

interface YouTubeChannelData {
  id: string;
  snippet?: {
    title?: string;
    thumbnails?: {
      default?: {
        url?: string;
      };
    };
  };
  statistics?: {
    viewCount?: string;
    commentCount?: string;
    subscriberCount?: string;
    videoCount?: string;
  };
}

export function useYouTubeAuth() {
  const [isAuthenticating, setIsAuthenticating] = useState(false);
  const addNotification = useNotificationStore(state => state.addNotification);
  const { addAccount } = useSocialAccountsStore();

  const authenticate = useCallback(async () => {
    try {
      setIsAuthenticating(true);

      // Generate and store state parameter
      const state = Math.random().toString(36).substring(7);
      sessionStorage.setItem('youtube_auth_state', state);

      // Get current redirect URI
      const redirectUri = config.redirectUri;
      console.log('Using redirect URI:', redirectUri); // Debug log

      // Construct auth URL with encoded redirect URI
      const params = new URLSearchParams({
        client_id: config.clientId,
        redirect_uri: redirectUri,
        response_type: 'code',
        scope: config.scope,
        access_type: 'offline',
        state: state,
        prompt: 'consent'
      });

      const authUrl = `https://accounts.google.com/o/oauth2/v2/auth?${params.toString()}`;
      console.log('Auth URL:', authUrl); // Debug log

      // Open popup
      const popup = window.open(
        authUrl,
        'YouTube OAuth',
        'width=600,height=700,left=200,top=100'
      );

      if (!popup) {
        throw new Error('Popup blocked. Please allow popups for this site.');
      }

      // Handle the OAuth response
      const result = await new Promise((resolve, reject) => {
        const handleMessage = async (event: MessageEvent) => {
          if (event.origin !== window.location.origin) return;

          if (event.data.type === 'GOOGLE_OAUTH_SUCCESS') {
            try {
              // Verify state parameter
              const returnedState = event.data.state;
              const savedState = sessionStorage.getItem('youtube_auth_state');

              if (returnedState !== savedState) {
                throw new Error('Invalid state parameter');
              }

              // Exchange code for tokens
              const tokenResponse = await axios.post('https://oauth2.googleapis.com/token', {
                code: event.data.code,
                client_id: config.clientId,
                client_secret: config.clientSecret,
                redirect_uri: redirectUri,
                grant_type: 'authorization_code',
              });

              const tokens = tokenResponse.data;

              // Store tokens
              localStorage.setItem('youtube_access_token', tokens.access_token);
              if (tokens.refresh_token) {
                localStorage.setItem('youtube_refresh_token', tokens.refresh_token);
              }

              // Get channel info
              const channelResponse = await axios.get<{ items: YouTubeChannelData[] }>(
                'https://www.googleapis.com/youtube/v3/channels',
                {
                  params: {
                    part: 'snippet,statistics',
                    mine: true
                  },
                  headers: {
                    'Authorization': `Bearer ${tokens.access_token}`
                  }
                }
              );

              const channel = channelResponse.data.items?.[0];

              if (!channel) {
                throw new Error('No channel data found');
              }

              addAccount({
                id: channel.id,
                platform: 'youtube',
                username: channel.snippet?.title || '',
                profileImage: channel.snippet?.thumbnails?.default?.url || '',
                metrics: {
                  likes: 0,
                  comments: parseInt(channel.statistics?.commentCount || '0'),
                  shares: 0,
                  posts: parseInt(channel.statistics?.videoCount || '0'),
                  engagement: calculateEngagement(channel.statistics),
                  reach: parseInt(channel.statistics?.viewCount || '0')
                },
                isConnected: true,
                lastPostDate: new Date()
              });

              toast.success(`Connected to YouTube channel: ${channel.snippet?.title}`);
              resolve(tokens);
            } catch (error) {
              console.error('YouTube API Error:', error);
              reject(error);
            }
          } else if (event.data.type === 'GOOGLE_OAUTH_ERROR') {
            reject(new Error(event.data.error || 'Authentication failed'));
          }
        };

        window.addEventListener('message', handleMessage);

        // Clean up event listener when popup closes
        const checkClosed = setInterval(() => {
          if (popup.closed) {
            clearInterval(checkClosed);
            window.removeEventListener('message', handleMessage);
            reject(new Error('Authentication cancelled'));
          }
        }, 1000);

        // Clean up interval after 5 minutes (timeout)
        setTimeout(() => {
          clearInterval(checkClosed);
          window.removeEventListener('message', handleMessage);
          reject(new Error('Authentication timed out'));
        }, 300000);
      });

      addNotification({
        type: 'success',
        title: 'YouTube Connected',
        message: 'Successfully connected your YouTube account',
        platform: 'youtube'
      });

      return result;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Failed to connect YouTube account';
      console.error('YouTube Auth Error:', error);
      toast.error(errorMessage);
      addNotification({
        type: 'error',
        title: 'Connection Failed',
        message: errorMessage,
        platform: 'youtube'
      });
      throw error;
    } finally {
      setIsAuthenticating(false);
      sessionStorage.removeItem('youtube_auth_state');
    }
  }, [addNotification, addAccount]);

  return {
    authenticate,
    isAuthenticating
  };
}

function calculateEngagement(statistics?: YouTubeChannelData['statistics']) {
  if (!statistics) return 0;
  
  const views = parseInt(statistics.viewCount || '0');
  const comments = parseInt(statistics.commentCount || '0');
  
  if (views === 0) return 0;
  
  return Number(((comments / views) * 100).toFixed(2));
}