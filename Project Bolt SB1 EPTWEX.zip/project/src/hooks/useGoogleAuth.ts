import { useState, useCallback } from 'react';
import { oauth2Client, getAuthUrl } from '../config/google';
import { useNotificationStore } from '../store/useNotificationStore';
import { useSocialAccountsStore } from '../store/useSocialAccountsStore';

export function useGoogleAuth() {
  const [isAuthenticating, setIsAuthenticating] = useState(false);
  const addNotification = useNotificationStore(state => state.addNotification);
  const { addAccount } = useSocialAccountsStore();

  const authenticate = useCallback(async () => {
    try {
      setIsAuthenticating(true);
      const authUrl = getAuthUrl();
      
      const popup = window.open(
        authUrl,
        'Google OAuth',
        'width=600,height=700,left=200,top=100'
      );

      const result = await new Promise((resolve, reject) => {
        const handleMessage = async (event: MessageEvent) => {
          if (event.origin !== window.location.origin) return;
          
          if (event.data.type === 'GOOGLE_OAUTH_SUCCESS') {
            try {
              const { tokens } = await oauth2Client.getToken(event.data.code);
              await oauth2Client.setCredentials(tokens);
              
              // Get YouTube channel info
              const youtube = google.youtube({ version: 'v3', auth: oauth2Client });
              const channelResponse = await youtube.channels.list({
                part: ['snippet,statistics'],
                mine: true
              });

              const channel = channelResponse.data.items?.[0];
              if (channel) {
                addAccount({
                  id: channel.id!,
                  platform: 'youtube',
                  username: channel.snippet?.title || '',
                  profileImage: channel.snippet?.thumbnails?.default?.url || '',
                  metrics: {
                    subscribers: parseInt(channel.statistics?.subscriberCount || '0'),
                    views: parseInt(channel.statistics?.viewCount || '0'),
                    videos: parseInt(channel.statistics?.videoCount || '0'),
                    likes: 0,
                    comments: 0,
                    shares: 0,
                    posts: parseInt(channel.statistics?.videoCount || '0'),
                    engagement: 0,
                    reach: parseInt(channel.statistics?.viewCount || '0')
                  },
                  isConnected: true,
                  lastPostDate: new Date()
                });
              }

              resolve(tokens);
            } catch (error) {
              reject(error);
            }
            popup?.close();
          }
        };

        window.addEventListener('message', handleMessage);
        popup?.addEventListener('close', () => {
          window.removeEventListener('message', handleMessage);
        });
      });

      addNotification({
        type: 'success',
        title: 'YouTube Connected',
        message: 'Successfully connected your YouTube account',
        platform: 'youtube'
      });

      return result;
    } catch (error) {
      console.error('Google Auth Error:', error);
      addNotification({
        type: 'error',
        title: 'Connection Failed',
        message: 'Failed to connect YouTube account. Please try again.',
        platform: 'youtube'
      });
      throw error;
    } finally {
      setIsAuthenticating(false);
    }
  }, [addNotification, addAccount]);

  return {
    authenticate,
    isAuthenticating
  };
}