import React from 'react';
import { Users, TrendingUp, Activity } from 'lucide-react';
import { Card, CardHeader, CardContent } from '../../components/ui/Card';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
} from 'chart.js';
import { Line } from 'react-chartjs-2';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

const mockCompetitorData = {
  labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
  datasets: [
    {
      label: 'Your Brand',
      data: [4000, 4500, 5000, 4800, 5200, 5500],
      borderColor: '#8884d8',
      tension: 0.4,
    },
    {
      label: 'Competitor 1',
      data: [3000, 3300, 3600, 3400, 3800, 4000],
      borderColor: '#82ca9d',
      tension: 0.4,
    },
    {
      label: 'Competitor 2',
      data: [4500, 4800, 4600, 5000, 5200, 5400],
      borderColor: '#ffc658',
      tension: 0.4,
    },
  ],
};

const competitors = [
  { id: 1, name: 'Competitor 1', growth: '+15%', followers: '125K', engagement: '4.8%' },
  { id: 2, name: 'Competitor 2', growth: '+12%', followers: '98K', engagement: '5.2%' },
];

const chartOptions = {
  responsive: true,
  plugins: {
    legend: {
      position: 'bottom' as const,
    },
  },
  scales: {
    y: {
      beginAtZero: true,
    },
  },
};

export default function CompetitorAnalysis() {
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <h3 className="text-lg font-semibold">Competitor Analysis</h3>
        </CardHeader>
        <CardContent>
          <div className="h-80">
            <Line data={mockCompetitorData} options={chartOptions} />
          </div>
        </CardContent>
      </Card>

      <div className="grid md:grid-cols-2 gap-6">
        {competitors.map((competitor) => (
          <Card key={competitor.id}>
            <CardHeader>
              <h4 className="font-semibold">{competitor.name}</h4>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-3 gap-4">
                <div className="text-center">
                  <div className="flex items-center justify-center mb-2">
                    <TrendingUp className="w-5 h-5 text-green-500" />
                  </div>
                  <p className="text-sm text-gray-500">Growth</p>
                  <p className="font-semibold">{competitor.growth}</p>
                </div>
                <div className="text-center">
                  <div className="flex items-center justify-center mb-2">
                    <Users className="w-5 h-5 text-blue-500" />
                  </div>
                  <p className="text-sm text-gray-500">Followers</p>
                  <p className="font-semibold">{competitor.followers}</p>
                </div>
                <div className="text-center">
                  <div className="flex items-center justify-center mb-2">
                    <Activity className="w-5 h-5 text-purple-500" />
                  </div>
                  <p className="text-sm text-gray-500">Engagement</p>
                  <p className="font-semibold">{competitor.engagement}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}