import React from 'react';
import { Users, Clock, MapPin } from 'lucide-react';
import { Card, CardHeader, CardContent } from '../../components/ui/Card';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend
} from 'chart.js';
import { Pie, Bar } from 'react-chartjs-2';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend
);

const demographicsData = {
  labels: ['18-24', '25-34', '35-44', '45+'],
  datasets: [
    {
      data: [30, 40, 20, 10],
      backgroundColor: ['#8884d8', '#82ca9d', '#ffc658', '#ff7300'],
    },
  ],
};

const locationData = {
  labels: ['USA', 'UK', 'Canada', 'Australia', 'Others'],
  datasets: [
    {
      label: 'Users by Country',
      data: [45, 25, 15, 10, 5],
      backgroundColor: '#8884d8',
    },
  ],
};

const activityData = {
  labels: ['00:00', '03:00', '06:00', '09:00', '12:00', '15:00', '18:00', '21:00'],
  datasets: [
    {
      label: 'Engagement Rate',
      data: [20, 15, 30, 65, 80, 90, 85, 45],
      backgroundColor: '#82ca9d',
    },
  ],
};

const chartOptions = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: {
      position: 'bottom' as const,
    },
  },
};

export default function AudienceInsights() {
  return (
    <div className="space-y-6">
      <div className="grid md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <h3 className="text-lg font-semibold flex items-center gap-2">
              <Users className="w-5 h-5 text-purple-500" />
              Age Demographics
            </h3>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <Pie data={demographicsData} options={chartOptions} />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <h3 className="text-lg font-semibold flex items-center gap-2">
              <MapPin className="w-5 h-5 text-purple-500" />
              Geographic Distribution
            </h3>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <Bar data={locationData} options={chartOptions} />
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <h3 className="text-lg font-semibold flex items-center gap-2">
            <Clock className="w-5 h-5 text-purple-500" />
            Activity Times
          </h3>
        </CardHeader>
        <CardContent>
          <div className="h-64">
            <Bar data={activityData} options={chartOptions} />
          </div>
        </CardContent>
      </Card>
    </div>
  );
}