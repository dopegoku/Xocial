import React, { useState } from 'react';
import { Hash, TrendingUp, Users, BarChart2, Loader2 } from 'lucide-react';
import { Card, CardHeader, CardContent } from '../../components/ui/Card';
import Button from '../../components/ui/Button';
import Input from '../../components/ui/Input';

interface HashtagStats {
  name: string;
  posts: number;
  reach: number;
  engagement: number;
  trend: 'up' | 'down' | 'stable';
}

const mockHashtagData: HashtagStats[] = [
  {
    name: '#marketing',
    posts: 1500000,
    reach: 5000000,
    engagement: 4.2,
    trend: 'up'
  },
  {
    name: '#socialmedia',
    posts: 2000000,
    reach: 8000000,
    engagement: 3.8,
    trend: 'up'
  },
  // Add more mock data...
];

export default function HashtagAnalyzer() {
  const [searchTerm, setSearchTerm] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [hashtags, setHashtags] = useState<HashtagStats[]>(mockHashtagData);

  const handleAnalyze = async () => {
    setIsAnalyzing(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));
    setIsAnalyzing(false);
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <h3 className="text-lg font-semibold flex items-center gap-2">
            <Hash className="w-5 h-5 text-purple-500" />
            Hashtag Analyzer
          </h3>
        </CardHeader>
        <CardContent>
          <div className="flex gap-4">
            <Input
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Enter a hashtag to analyze"
              className="flex-1"
            />
            <Button
              onClick={handleAnalyze}
              disabled={isAnalyzing || !searchTerm}
            >
              {isAnalyzing ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Analyzing...
                </>
              ) : (
                'Analyze'
              )}
            </Button>
          </div>

          <div className="mt-6 space-y-4">
            {hashtags.map((hashtag) => (
              <div
                key={hashtag.name}
                className="bg-white dark:bg-gray-800 rounded-lg p-4 shadow-sm"
              >
                <div className="flex items-center justify-between mb-4">
                  <h4 className="font-semibold text-lg">{hashtag.name}</h4>
                  <span className={`flex items-center ${
                    hashtag.trend === 'up' ? 'text-green-500' : 
                    hashtag.trend === 'down' ? 'text-red-500' : 'text-gray-500'
                  }`}>
                    <TrendingUp className="w-4 h-4 mr-1" />
                    Trending
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <p className="text-sm text-gray-500 mb-1">Total Posts</p>
                    <p className="font-semibold">{hashtag.posts.toLocaleString()}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500 mb-1">Reach</p>
                    <p className="font-semibold">{hashtag.reach.toLocaleString()}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500 mb-1">Engagement</p>
                    <p className="font-semibold">{hashtag.engagement}%</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}