import React, { useState } from 'react';
import { Image, Video, Link, Hash, Clock, Globe, Sparkles, Scissors } from 'lucide-react';
import { Card, CardHeader, CardContent } from '../../components/ui/Card';
import Button from '../../components/ui/Button';
import Textarea from '../../components/ui/Textarea';
import { useDropzone } from 'react-dropzone';
import type { SocialPlatform } from '../../types';

interface PlatformContentEditorProps {
  platform: SocialPlatform;
  onContentChange: (content: PlatformContent) => void;
}

export interface PlatformContent {
  text: string;
  media: File[];
  hashtags: string[];
  scheduledTime?: Date;
  isReels?: boolean;
  isStory?: boolean;
}

const platformConfigs = {
  instagram: {
    maxCharacters: 2200,
    maxHashtags: 30,
    maxMedia: 10,
    supportedMediaTypes: ['image/jpeg', 'image/png', 'video/mp4'],
    maxVideoLength: 60, // seconds
    maxImageSize: 8388608, // 8MB
    aspectRatios: ['1:1', '4:5', '16:9'],
    features: ['stories', 'reels', 'carousel']
  },
  facebook: {
    maxCharacters: 63206,
    maxMedia: 10,
    supportedMediaTypes: ['image/*', 'video/*', 'application/pdf'],
    maxVideoLength: 240,
    maxImageSize: 104857600, // 100MB
    features: ['stories', 'live', 'events']
  },
  twitter: {
    maxCharacters: 280,
    maxMedia: 4,
    supportedMediaTypes: ['image/jpeg', 'image/png', 'video/mp4', 'image/gif'],
    maxVideoLength: 140,
    maxImageSize: 5242880, // 5MB
    features: ['polls', 'spaces']
  },
  youtube: {
    maxCharacters: 5000,
    supportedMediaTypes: ['video/mp4', 'video/quicktime'],
    maxVideoLength: 43200, // 12 hours
    maxVideoSize: 134217728000, // 128GB
    features: ['shorts', 'live', 'premiere']
  }
};

export default function PlatformContentEditor({ platform, onContentChange }: PlatformContentEditorProps) {
  const [content, setContent] = useState<PlatformContent>({
    text: '',
    media: [],
    hashtags: [],
    isReels: false,
    isStory: false
  });

  const config = platformConfigs[platform];

  const { getRootProps, getInputProps } = useDropzone({
    accept: {
      'image/*': config.supportedMediaTypes.filter(type => type.startsWith('image')),
      'video/*': config.supportedMediaTypes.filter(type => type.startsWith('video'))
    },
    maxFiles: config.maxMedia,
    onDrop: (acceptedFiles) => {
      setContent(prev => ({
        ...prev,
        media: [...prev.media, ...acceptedFiles].slice(0, config.maxMedia)
      }));
      onContentChange({
        ...content,
        media: [...content.media, ...acceptedFiles].slice(0, config.maxMedia)
      });
    }
  });

  const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const newText = e.target.value;
    if (newText.length <= config.maxCharacters) {
      setContent(prev => ({ ...prev, text: newText }));
      onContentChange({ ...content, text: newText });
    }
  };

  const handleContentTypeChange = (type: 'regular' | 'story' | 'reels') => {
    setContent(prev => ({
      ...prev,
      isReels: type === 'reels',
      isStory: type === 'story'
    }));
    onContentChange({
      ...content,
      isReels: type === 'reels',
      isStory: type === 'story'
    });
  };

  return (
    <Card>
      <CardHeader>
        <h3 className="text-lg font-semibold capitalize">{platform} Content</h3>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Content Type Selection */}
        <div className="flex space-x-2">
          <Button
            variant={!content.isReels && !content.isStory ? 'primary' : 'secondary'}
            onClick={() => handleContentTypeChange('regular')}
          >
            Regular Post
          </Button>
          {config.features.includes('stories') && (
            <Button
              variant={content.isStory ? 'primary' : 'secondary'}
              onClick={() => handleContentTypeChange('story')}
            >
              Story
            </Button>
          )}
          {(config.features.includes('reels') || config.features.includes('shorts')) && (
            <Button
              variant={content.isReels ? 'primary' : 'secondary'}
              onClick={() => handleContentTypeChange('reels')}
            >
              {platform === 'youtube' ? 'Shorts' : 'Reels'}
            </Button>
          )}
        </div>

        {/* Media Upload */}
        <div
          {...getRootProps()}
          className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-6 text-center cursor-pointer hover:border-purple-500 transition-colors"
        >
          <input {...getInputProps()} />
          <div className="space-y-2">
            <div className="flex justify-center">
              {content.isReels || content.isStory ? (
                <Video className="w-12 h-12 text-gray-400" />
              ) : (
                <Image className="w-12 h-12 text-gray-400" />
              )}
            </div>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Drag & drop or click to upload
              {content.isReels || content.isStory ? ' video' : ' media'}
            </p>
            <p className="text-xs text-gray-500">
              Max size: {(config.maxImageSize / 1048576).toFixed(0)}MB
              {config.features.includes('reels') && ' (Videos: 15s - 60s)'}
            </p>
          </div>
        </div>

        {/* Media Preview */}
        {content.media.length > 0 && (
          <div className="grid grid-cols-3 gap-4">
            {content.media.map((file, index) => (
              <div key={index} className="relative aspect-square rounded-lg overflow-hidden">
                {file.type.startsWith('image/') ? (
                  <img
                    src={URL.createObjectURL(file)}
                    alt={`Upload ${index + 1}`}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <video
                    src={URL.createObjectURL(file)}
                    className="w-full h-full object-cover"
                    controls
                  />
                )}
                <button
                  onClick={() => {
                    const newMedia = content.media.filter((_, i) => i !== index);
                    setContent(prev => ({ ...prev, media: newMedia }));
                    onContentChange({ ...content, media: newMedia });
                  }}
                  className="absolute top-2 right-2 p-1 bg-red-500 text-white rounded-full hover:bg-red-600"
                >
                  ×
                </button>
              </div>
            ))}
          </div>
        )}

        {/* Text Content */}
        <Textarea
          value={content.text}
          onChange={handleTextChange}
          placeholder={`Write your ${platform} post...`}
          className="min-h-[120px]"
        />
        <p className="text-sm text-gray-500">
          {content.text.length}/{config.maxCharacters} characters
        </p>

        {/* Platform-specific features */}
        <div className="flex flex-wrap gap-2">
          {platform === 'twitter' && (
            <Button variant="secondary" size="sm">
              Add Poll
            </Button>
          )}
          {platform === 'youtube' && (
            <>
              <Button variant="secondary" size="sm">
                Set Thumbnail
              </Button>
              <Button variant="secondary" size="sm">
                Add Cards
              </Button>
            </>
          )}
          {(platform === 'instagram' || platform === 'facebook') && (
            <Button variant="secondary" size="sm">
              Tag People
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}