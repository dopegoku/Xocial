import axios from 'axios';
import config from '../../config/facebook';
import { useSocialAccountsStore } from '../../store/useSocialAccountsStore';
import toast from 'react-hot-toast';

declare global {
  interface Window {
    FB: {
      init: (options: any) => void;
      login: (callback: (response: any) => void, options: any) => void;
      api: (path: string, options: any) => Promise<any>;
    };
    fbAsyncInit: () => void;
  }
}

// Initialize Facebook SDK
export function initFacebookSDK(): Promise<void> {
  return new Promise((resolve) => {
    // Load the SDK asynchronously
    (function (d, s, id) {
      var js,
        fjs = d.getElementsByTagName(s)[0];
      if (d.getElementById(id)) return;
      js = d.createElement(s) as HTMLScriptElement;
      js.id = id;
      js.src = "https://connect.facebook.net/en_US/sdk.js";
      fjs.parentNode?.insertBefore(js, fjs);
    })(document, 'script', 'facebook-jssdk');

    window.fbAsyncInit = function () {
      window.FB.init({
        appId: config.appId,
        cookie: true,
        xfbml: true,
        version: config.version
      });
      resolve();
    };
  });
}

// Handle Facebook Login
export async function handleFacebookLogin(): Promise<any> {
  const { addAccount } = useSocialAccountsStore.getState();

  return new Promise((resolve, reject) => {
    window.FB.login(
      async function(response) {
        if (response.authResponse) {
          try {
            // Get user profile
            const userResponse = await window.FB.api('/me', { fields: config.fields });
            
            // Handle Facebook Pages
            if (userResponse.accounts && userResponse.accounts.data) {
              for (const page of userResponse.accounts.data) {
                // Add Facebook Page
                addAccount({
                  id: page.id,
                  platform: 'facebook',
                  username: page.name,
                  profileImage: page.picture.data.url,
                  accessToken: page.access_token,
                  metrics: {
                    likes: 0,
                    comments: 0,
                    shares: 0,
                    posts: 0,
                    engagement: 0,
                    reach: 0
                  },
                  isConnected: true,
                  lastPostDate: new Date()
                });

                // If page has Instagram Business Account
                if (page.instagram_business_account) {
                  const igAccount = page.instagram_business_account;
                  addAccount({
                    id: igAccount.id,
                    platform: 'instagram',
                    username: igAccount.username,
                    profileImage: igAccount.profile_picture_url,
                    accessToken: page.access_token,
                    metrics: {
                      likes: 0,
                      comments: 0,
                      shares: 0,
                      posts: 0,
                      engagement: 0,
                      reach: 0
                    },
                    isConnected: true,
                    lastPostDate: new Date()
                  });
                }
              }
            }

            toast.success('Successfully connected Facebook account');
            resolve(response.authResponse);
          } catch (error) {
            console.error('Facebook API Error:', error);
            toast.error('Failed to fetch Facebook account data');
            reject(error);
          }
        } else {
          reject(new Error('Facebook login failed'));
        }
      },
      {
        scope: config.scope,
        return_scopes: true
      }
    );
  });
}

// Get long-lived access token
export async function getLongLivedToken(accessToken: string): Promise<string> {
  try {
    const response = await axios.get(
      `https://graph.facebook.com/${config.version}/oauth/access_token`,
      {
        params: {
          grant_type: 'fb_exchange_token',
          client_id: config.appId,
          client_secret: config.appSecret,
          fb_exchange_token: accessToken
        }
      }
    );
    return response.data.access_token;
  } catch (error) {
    console.error('Error getting long-lived token:', error);
    throw error;
  }
}

// Get page insights
export async function getPageInsights(pageId: string, accessToken: string) {
  try {
    const response = await axios.get(
      `https://graph.facebook.com/${config.version}/${pageId}/insights`,
      {
        params: {
          access_token: accessToken,
          metric: [
            'page_impressions',
            'page_engaged_users',
            'page_post_engagements',
            'page_fans',
            'page_fan_adds'
          ].join(','),
          period: 'day',
          date_preset: 'last_30days'
        }
      }
    );
    return response.data.data;
  } catch (error) {
    console.error('Error fetching page insights:', error);
    throw error;
  }
}

// Post to Facebook Page
export async function postToFacebook(pageId: string, accessToken: string, content: string, mediaUrl?: string) {
  try {
    const endpoint = `https://graph.facebook.com/${config.version}/${pageId}/feed`;
    const params: any = {
      message: content,
      access_token: accessToken
    };

    if (mediaUrl) {
      params.link = mediaUrl;
    }

    const response = await axios.post(endpoint, null, { params });
    return response.data;
  } catch (error) {
    console.error('Error posting to Facebook:', error);
    throw error;
  }
}

// Schedule a post
export async function scheduleFacebookPost(
  pageId: string,
  accessToken: string,
  content: string,
  scheduledTime: Date,
  mediaUrl?: string
) {
  try {
    const endpoint = `https://graph.facebook.com/${config.version}/${pageId}/feed`;
    const params: any = {
      message: content,
      access_token: accessToken,
      scheduled_publish_time: Math.floor(scheduledTime.getTime() / 1000)
    };

    if (mediaUrl) {
      params.link = mediaUrl;
    }

    const response = await axios.post(endpoint, null, { params });
    return response.data;
  } catch (error) {
    console.error('Error scheduling Facebook post:', error);
    throw error;
  }
}

// Get Instagram insights
export async function getInstagramInsights(igAccountId: string, accessToken: string) {
  try {
    const response = await axios.get(
      `https://graph.facebook.com/${config.version}/${igAccountId}/insights`,
      {
        params: {
          access_token: accessToken,
          metric: [
            'impressions',
            'reach',
            'profile_views',
            'follower_count'
          ].join(','),
          period: 'day',
          date_preset: 'last_30days'
        }
      }
    );
    return response.data.data;
  } catch (error) {
    console.error('Error fetching Instagram insights:', error);
    throw error;
  }
}

// Get Instagram media
export async function getInstagramMedia(igAccountId: string, accessToken: string) {
  try {
    const response = await axios.get(
      `https://graph.facebook.com/${config.version}/${igAccountId}/media`,
      {
        params: {
          access_token: accessToken,
          fields: [
            'id',
            'caption',
            'media_type',
            'media_url',
            'thumbnail_url',
            'permalink',
            'timestamp',
            'like_count',
            'comments_count'
          ].join(','),
          limit: 25
        }
      }
    );
    return response.data.data;
  } catch (error) {
    console.error('Error fetching Instagram media:', error);
    throw error;
  }
}