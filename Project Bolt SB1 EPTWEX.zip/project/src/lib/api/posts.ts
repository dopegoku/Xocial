import { collection, addDoc, updateDoc, deleteDoc, doc, getDocs, query, where } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { db, storage } from '../../config/firebase';
import type { Post, DraftPost } from '../../types';

export async function createPost(post: DraftPost) {
  const mediaUrls = [];
  
  if (post.media) {
    for (const file of post.media) {
      const storageRef = ref(storage, `posts/${file.name}`);
      await uploadBytes(storageRef, file);
      const url = await getDownloadURL(storageRef);
      mediaUrls.push(url);
    }
  }

  const newPost = {
    ...post,
    media: mediaUrls,
    status: 'scheduled',
    createdAt: new Date(),
    updatedAt: new Date(),
  };

  const docRef = await addDoc(collection(db, 'posts'), newPost);
  return { id: docRef.id, ...newPost };
}

export async function updatePost(postId: string, updates: Partial<Post>) {
  const postRef = doc(db, 'posts', postId);
  await updateDoc(postRef, {
    ...updates,
    updatedAt: new Date(),
  });
}

export async function deletePost(postId: string) {
  const postRef = doc(db, 'posts', postId);
  await deleteDoc(postRef);
}

export async function getScheduledPosts() {
  const q = query(
    collection(db, 'posts'),
    where('status', '==', 'scheduled')
  );
  
  const snapshot = await getDocs(q);
  return snapshot.docs.map(doc => ({
    id: doc.id,
    ...doc.data(),
  })) as Post[];
}