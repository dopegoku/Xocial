import {
  signInWithPopup,
  GoogleAuthProvider,
  GithubAuthProvider,
  TwitterAuthProvider,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword as firebaseSignInWithEmailPassword,
  updateProfile,
} from 'firebase/auth';
import { doc, setDoc, getDoc, updateDoc } from 'firebase/firestore';
import { auth, db } from '../../config/firebase';
import type { User } from '../../types';
import { handleApiError } from './errorHandler';

const googleProvider = new GoogleAuthProvider();
googleProvider.addScope('https://www.googleapis.com/auth/youtube');
googleProvider.addScope('https://www.googleapis.com/auth/youtube.upload');
googleProvider.addScope('https://www.googleapis.com/auth/youtube.readonly');
googleProvider.addScope('https://www.googleapis.com/auth/userinfo.profile');
googleProvider.addScope('https://www.googleapis.com/auth/userinfo.email');

const githubProvider = new GithubAuthProvider();
const twitterProvider = new TwitterAuthProvider();

export async function signInWithProvider(provider: 'google' | 'github' | 'twitter'): Promise<User> {
  try {
    const authProvider = {
      google: googleProvider,
      github: githubProvider,
      twitter: twitterProvider,
    }[provider];

    const result = await signInWithPopup(auth, authProvider);
    const user = result.user;

    // Check if user exists in Firestore
    const userDoc = await getDoc(doc(db, 'users', user.uid));
    
    if (!userDoc.exists()) {
      // Create new user document
      const newUser: User = {
        id: user.uid,
        name: user.displayName || '',
        email: user.email || '',
        avatar: user.photoURL || '',
        theme: 'light',
        accounts: [],
        onboardingCompleted: false,
      };

      await setDoc(doc(db, 'users', user.uid), newUser);
      return newUser;
    }

    return userDoc.data() as User;
  } catch (error) {
    return handleApiError(error);
  }
}

// Alias for signInWithProvider to maintain backward compatibility
export const signUpWithProvider = signInWithProvider;

export async function signUpWithEmailPassword(email: string, password: string, name: string): Promise<User> {
  try {
    const result = await createUserWithEmailAndPassword(auth, email, password);
    const user = result.user;

    // Update profile with name
    await updateProfile(user, { displayName: name });

    // Create user document in Firestore
    const newUser: User = {
      id: user.uid,
      name,
      email: user.email || '',
      avatar: user.photoURL || '',
      theme: 'light',
      accounts: [],
      onboardingCompleted: false,
    };

    await setDoc(doc(db, 'users', user.uid), newUser);
    return newUser;
  } catch (error) {
    return handleApiError(error);
  }
}

export async function signInWithEmailPassword(email: string, password: string): Promise<User> {
  try {
    const result = await firebaseSignInWithEmailPassword(auth, email, password);
    const userDoc = await getDoc(doc(db, 'users', result.user.uid));
    
    if (!userDoc.exists()) {
      throw new Error('User document not found');
    }
    
    return userDoc.data() as User;
  } catch (error) {
    return handleApiError(error);
  }
}

export async function updateUserProfile(userId: string, userData: Partial<User>): Promise<Partial<User>> {
  try {
    const userRef = doc(db, 'users', userId);
    await updateDoc(userRef, userData);
    return userData;
  } catch (error) {
    return handleApiError(error);
  }
}

export async function signOut(): Promise<void> {
  try {
    await auth.signOut();
  } catch (error) {
    return handleApiError(error);
  }
}

export async function getCurrentUser(): Promise<User | null> {
  try {
    const user = auth.currentUser;
    if (!user) return null;

    const userDoc = await getDoc(doc(db, 'users', user.uid));
    if (!userDoc.exists()) return null;

    return userDoc.data() as User;
  } catch (error) {
    return handleApiError(error);
  }
}