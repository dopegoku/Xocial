import { google } from 'googleapis';
import { OAuth2Client } from 'google-auth-library';

export class GoogleAPIClient {
  private static instance: GoogleAPIClient;
  private oauth2Client: OAuth2Client;

  private constructor() {
    this.oauth2Client = new OAuth2Client(
      import.meta.env.VITE_GOOGLE_CLIENT_ID,
      import.meta.env.VITE_GOOGLE_CLIENT_SECRET,
      `${window.location.origin}/auth/google/callback`
    );
  }

  public static getInstance(): GoogleAPIClient {
    if (!GoogleAPIClient.instance) {
      GoogleAPIClient.instance = new GoogleAPIClient();
    }
    return GoogleAPIClient.instance;
  }

  public getYouTubeClient() {
    return google.youtube({
      version: 'v3',
      auth: this.oauth2Client
    });
  }

  public async setCredentials(tokens: any) {
    this.oauth2Client.setCredentials(tokens);
  }

  public getAuthUrl() {
    return this.oauth2Client.generateAuthUrl({
      access_type: 'offline',
      scope: [
        'https://www.googleapis.com/auth/youtube.readonly',
        'https://www.googleapis.com/auth/youtube.upload'
      ]
    });
  }

  public async getTokens(code: string) {
    const { tokens } = await this.oauth2Client.getToken(code);
    return tokens;
  }
}</content>
<boltAction type="file" filePath="src/lib/api/youtube.ts">import { GoogleAPIClient } from './google';
import type { VideoListResponse } from 'googleapis/build/src/apis/youtube/v3';

export async function getYouTubeAnalytics() {
  try {
    const client = GoogleAPIClient.getInstance();
    const youtube = client.getYouTubeClient();

    const response = await youtube.channels.list({
      part: ['statistics'],
      mine: true
    });

    return response.data;
  } catch (error) {
    console.error('YouTube API Error:', error);
    throw error;
  }
}

export async function getYouTubeVideos(): Promise<VideoListResponse> {
  try {
    const client = GoogleAPIClient.getInstance();
    const youtube = client.getYouTubeClient();

    const response = await youtube.search.list({
      part: ['snippet'],
      forMine: true,
      type: ['video'],
      maxResults: 50
    });

    return response.data;
  } catch (error) {
    console.error('YouTube API Error:', error);
    throw error;
  }
}</content>
<boltAction type="file" filePath="src/hooks/useGoogleAuth.ts">import { useState, useCallback } from 'react';
import { GoogleAPIClient } from '../lib/api/google';
import { useNotificationStore } from '../store/useNotificationStore';

export function useGoogleAuth() {
  const [isAuthenticating, setIsAuthenticating] = useState(false);
  const addNotification = useNotificationStore(state => state.addNotification);

  const authenticate = useCallback(async () => {
    try {
      setIsAuthenticating(true);
      const client = GoogleAPIClient.getInstance();
      const authUrl = client.getAuthUrl();
      
      // Open popup for OAuth
      const popup = window.open(
        authUrl,
        'Google OAuth',
        'width=600,height=700,left=200,top=100'
      );

      const result = await new Promise((resolve, reject) => {
        window.addEventListener('message', async (event) => {
          if (event.origin !== window.location.origin) return;
          
          if (event.data.type === 'GOOGLE_OAUTH_SUCCESS') {
            try {
              const tokens = await client.getTokens(event.data.code);
              await client.setCredentials(tokens);
              resolve(tokens);
            } catch (error) {
              reject(error);
            }
            popup?.close();
          }
        });
      });

      addNotification({
        type: 'success',
        title: 'YouTube Connected',
        message: 'Successfully connected your YouTube account',
        platform: 'youtube'
      });

      return result;
    } catch (error) {
      console.error('Google Auth Error:', error);
      addNotification({
        type: 'error',
        title: 'Connection Failed',
        message: 'Failed to connect YouTube account. Please try again.',
        platform: 'youtube'
      });
      throw error;
    } finally {
      setIsAuthenticating(false);
    }
  }, [addNotification]);

  return {
    authenticate,
    isAuthenticating
  };
}</content>
<boltAction type="shell">
<command>npm run dev</command>