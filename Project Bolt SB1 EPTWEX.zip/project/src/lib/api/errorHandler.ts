import toast from 'react-hot-toast';

interface ErrorResponse {
  code?: string;
  message?: string;
}

export function handleApiError(error: any) {
  console.error('API Error:', error);

  const errorResponse: ErrorResponse = error.response?.data || error;
  const errorMessage = errorResponse.message || 'An unexpected error occurred';

  // Handle specific error codes
  switch (errorResponse.code) {
    case 'auth/user-not-found':
      toast.error('User not found. Please check your credentials.');
      break;
    case 'auth/wrong-password':
      toast.error('Invalid password. Please try again.');
      break;
    case 'auth/email-already-in-use':
      toast.error('Email is already registered. Please sign in instead.');
      break;
    case 'auth/invalid-email':
      toast.error('Invalid email address.');
      break;
    case 'auth/weak-password':
      toast.error('Password is too weak. Please use a stronger password.');
      break;
    case 'storage/unauthorized':
      toast.error('Unauthorized access to storage. Please sign in again.');
      break;
    case 'storage/quota-exceeded':
      toast.error('Storage quota exceeded. Please contact support.');
      break;
    default:
      toast.error(errorMessage);
  }

  throw error;
}