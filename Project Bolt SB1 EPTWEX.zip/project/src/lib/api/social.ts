import axios from 'axios';
import { API_CONFIG } from '../../config/api';
import type { SocialPlatform } from '../../types';

// OAuth URLs
const OAUTH_URLS = {
  facebook: `https://www.facebook.com/v19.0/dialog/oauth`,
  twitter: 'https://twitter.com/i/oauth2/authorize',
  instagram: `https://api.instagram.com/oauth/authorize`,
  youtube: 'https://accounts.google.com/o/oauth2/v2/auth'
};

export async function initiateOAuthFlow(platform: SocialPlatform) {
  const config = API_CONFIG[platform];
  let authUrl = '';

  switch (platform) {
    case 'facebook':
      authUrl = `${OAUTH_URLS.facebook}?client_id=${config.appId}&redirect_uri=${window.location.origin}/auth/facebook/callback&scope=${config.scope}`;
      break;
    case 'twitter':
      authUrl = `${OAUTH_URLS.twitter}?client_id=${config.apiKey}&redirect_uri=${config.callbackUrl}&scope=${config.scope}&response_type=code`;
      break;
    case 'instagram':
      authUrl = `${OAUTH_URLS.instagram}?client_id=${config.clientId}&redirect_uri=${window.location.origin}/auth/instagram/callback&scope=${config.scope}&response_type=code`;
      break;
    case 'youtube':
      authUrl = `${OAUTH_URLS.youtube}?client_id=${config.clientId}&redirect_uri=${window.location.origin}/auth/youtube/callback&scope=${config.scope}&response_type=code&access_type=offline`;
      break;
    default:
      throw new Error(`Unsupported platform: ${platform}`);
  }

  // Open OAuth window
  const width = 600;
  const height = 700;
  const left = window.screen.width / 2 - width / 2;
  const top = window.screen.height / 2 - height / 2;
  
  return new Promise((resolve, reject) => {
    const authWindow = window.open(
      authUrl,
      'OAuth',
      `width=${width},height=${height},left=${left},top=${top}`
    );

    // Handle the OAuth callback
    window.addEventListener('message', async (event) => {
      if (event.origin !== window.location.origin) return;

      if (event.data.type === 'OAUTH_SUCCESS') {
        try {
          const token = await exchangeCodeForToken(platform, event.data.code);
          resolve(token);
        } catch (error) {
          reject(error);
        }
        authWindow?.close();
      } else if (event.data.type === 'OAUTH_ERROR') {
        reject(new Error(event.data.error));
        authWindow?.close();
      }
    });
  });
}

async function exchangeCodeForToken(platform: SocialPlatform, code: string) {
  const config = API_CONFIG[platform];
  
  switch (platform) {
    case 'facebook':
      const fbResponse = await axios.get('https://graph.facebook.com/v19.0/oauth/access_token', {
        params: {
          client_id: config.appId,
          client_secret: config.appSecret,
          redirect_uri: `${window.location.origin}/auth/facebook/callback`,
          code
        }
      });
      return fbResponse.data.access_token;

    case 'twitter':
      const twResponse = await axios.post('https://api.twitter.com/2/oauth2/token', {
        code,
        grant_type: 'authorization_code',
        client_id: config.apiKey,
        redirect_uri: config.callbackUrl,
        code_verifier: localStorage.getItem('twitter_code_verifier')
      });
      return twResponse.data.access_token;

    case 'instagram':
      const igResponse = await axios.post('https://api.instagram.com/oauth/access_token', {
        client_id: config.clientId,
        client_secret: config.clientSecret,
        grant_type: 'authorization_code',
        redirect_uri: `${window.location.origin}/auth/instagram/callback`,
        code
      });
      return igResponse.data.access_token;

    case 'youtube':
      const ytResponse = await axios.post('https://oauth2.googleapis.com/token', {
        code,
        client_id: config.clientId,
        client_secret: config.clientSecret,
        redirect_uri: `${window.location.origin}/auth/youtube/callback`,
        grant_type: 'authorization_code'
      });
      return ytResponse.data.access_token;

    default:
      throw new Error(`Unsupported platform: ${platform}`);
  }
}