import axios, { AxiosError } from 'axios';

interface RetryConfig {
  maxRetries?: number;
  retryDelay?: number;
  shouldRetry?: (error: AxiosError) => boolean;
}

const defaultConfig: RetryConfig = {
  maxRetries: 3,
  retryDelay: 1000,
  shouldRetry: (error: AxiosError) => {
    // Retry on network errors or 5xx server errors
    return !error.response || (error.response.status >= 500 && error.response.status <= 599);
  },
};

export async function withRetry<T>(
  fn: () => Promise<T>,
  config: RetryConfig = {}
): Promise<T> {
  const { maxRetries, retryDelay, shouldRetry } = { ...defaultConfig, ...config };
  let lastError: Error | null = null;

  for (let attempt = 1; attempt <= maxRetries!; attempt++) {
    try {
      return await fn();
    } catch (error) {
      lastError = error as Error;

      if (
        attempt === maxRetries ||
        (axios.isAxiosError(error) && !shouldRetry!(error))
      ) {
        break;
      }

      await new Promise(resolve => setTimeout(resolve, retryDelay));
    }
  }

  throw lastError;
}