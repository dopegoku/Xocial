import axios from 'axios';
import config from '../../config/google';

export async function fetchYouTubeAnalytics() {
  const accessToken = localStorage.getItem('youtube_access_token');
  if (!accessToken) {
    throw new Error('No YouTube access token found');
  }

  try {
    // Get channel data
    const channelResponse = await axios.get(
      'https://www.googleapis.com/youtube/v3/channels',
      {
        params: {
          part: 'statistics,snippet',
          mine: true
        },
        headers: {
          Authorization: `Bearer ${accessToken}`
        }
      }
    );

    const channel = channelResponse.data.items[0];

    // Get recent videos
    const videosResponse = await axios.get(
      'https://www.googleapis.com/youtube/v3/search',
      {
        params: {
          part: 'snippet',
          channelId: channel.id,
          maxResults: 10,
          order: 'date',
          type: 'video'
        },
        headers: {
          Authorization: `Bearer ${accessToken}`
        }
      }
    );

    // Get video statistics
    const videoIds = videosResponse.data.items.map((item: any) => item.id.videoId);
    const videoStatsResponse = await axios.get(
      'https://www.googleapis.com/youtube/v3/videos',
      {
        params: {
          part: 'statistics',
          id: videoIds.join(',')
        },
        headers: {
          Authorization: `Bearer ${accessToken}`
        }
      }
    );

    return {
      channel: {
        id: channel.id,
        title: channel.snippet.title,
        description: channel.snippet.description,
        thumbnails: channel.snippet.thumbnails,
        statistics: channel.statistics
      },
      recentVideos: videosResponse.data.items.map((video: any, index: number) => ({
        ...video,
        statistics: videoStatsResponse.data.items[index]?.statistics
      }))
    };
  } catch (error) {
    console.error('Error fetching YouTube analytics:', error);
    throw error;
  }
}

export async function uploadYouTubeVideo(
  file: File,
  title: string,
  description: string,
  privacyStatus: 'private' | 'unlisted' | 'public' = 'private'
) {
  const accessToken = localStorage.getItem('youtube_access_token');
  if (!accessToken) {
    throw new Error('No YouTube access token found');
  }

  try {
    // First, create the video resource
    const createResponse = await axios.post(
      'https://www.googleapis.com/upload/youtube/v3/videos',
      {
        snippet: {
          title,
          description,
          categoryId: '22' // People & Blogs
        },
        status: {
          privacyStatus,
          selfDeclaredMadeForKids: false
        }
      },
      {
        params: {
          part: 'snippet,status',
          uploadType: 'resumable'
        },
        headers: {
          Authorization: `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        }
      }
    );

    // Get the upload URL from the response headers
    const uploadUrl = createResponse.headers.location;

    // Upload the video file
    await axios.put(uploadUrl, file, {
      headers: {
        'Content-Type': file.type,
        'Content-Length': file.size.toString()
      },
      onUploadProgress: (progressEvent) => {
        const percentCompleted = Math.round((progressEvent.loaded * 100) / progressEvent.total!);
        console.log(`Upload progress: ${percentCompleted}%`);
      }
    });

    return createResponse.data;
  } catch (error) {
    console.error('Error uploading video:', error);
    throw error;
  }
}