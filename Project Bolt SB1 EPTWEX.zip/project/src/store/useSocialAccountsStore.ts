import { create } from 'zustand';
import type { SocialAccount, SocialPlatform } from '../types';
import { useNotificationStore } from './useNotificationStore';

interface SocialAccountsState {
  accounts: SocialAccount[];
  setAccounts: (accounts: SocialAccount[]) => void;
  addAccount: (account: SocialAccount) => void;
  removeAccount: (id: string) => void;
  updateAccount: (id: string, updates: Partial<SocialAccount>) => void;
  syncAccount: (platform: SocialPlatform) => Promise<void>;
}

export const useSocialAccountsStore = create<SocialAccountsState>()((set) => ({
  accounts: [], // Removed demo data
  setAccounts: (accounts) => set({ accounts }),
  addAccount: (account) => {
    set((state) => ({ accounts: [...state.accounts, account] }));
    useNotificationStore.getState().addNotification({
      type: 'success',
      title: 'Account Connected',
      message: `Successfully connected ${account.platform} account: ${account.username}`,
      platform: account.platform
    });
  },
  removeAccount: (id) => {
    set((state) => {
      const account = state.accounts.find(a => a.id === id);
      if (account) {
        useNotificationStore.getState().addNotification({
          type: 'info',
          title: 'Account Removed',
          message: `Disconnected ${account.platform} account: ${account.username}`,
          platform: account.platform
        });
      }
      return { accounts: state.accounts.filter((account) => account.id !== id) };
    });
  },
  updateAccount: (id, updates) => set((state) => ({
    accounts: state.accounts.map((account) =>
      account.id === id ? { ...account, ...updates } : account
    ),
  })),
  syncAccount: async (platform) => {
    // Implement actual sync logic when needed
    throw new Error('Not implemented');
  }
}));