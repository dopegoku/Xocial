// Get the current domain for the redirect URI
const getDomain = () => {
  // For StackBlitz WebContainer environment
  if (window.location.hostname.includes('webcontainer.io')) {
    return window.location.origin;
  }
  
  // For local development
  if (process.env.NODE_ENV === 'development') {
    return 'http://localhost:5173';
  }
  
  // For production
  return 'https://your-production-domain.com';
};

// Get the current redirect URI
const getRedirectUri = () => {
  const domain = getDomain();
  return `${domain}/auth/youtube/callback`;
};

const config = {
  clientId: import.meta.env.VITE_GOOGLE_CLIENT_ID,
  clientSecret: import.meta.env.VITE_GOOGLE_CLIENT_SECRET,
  get redirectUri() {
    return getRedirectUri();
  },
  scope: [
    // YouTube Data API Scopes
    'https://www.googleapis.com/auth/youtube',
    'https://www.googleapis.com/auth/youtube.readonly',
    'https://www.googleapis.com/auth/youtube.upload',
    'https://www.googleapis.com/auth/youtube.force-ssl',
    'https://www.googleapis.com/auth/youtubepartner',
    
    // YouTube Analytics API Scopes
    'https://www.googleapis.com/auth/yt-analytics.readonly',
    'https://www.googleapis.com/auth/yt-analytics-monetary.readonly',
    
    // User Info Scopes
    'https://www.googleapis.com/auth/userinfo.email',
    'https://www.googleapis.com/auth/userinfo.profile',
    
    // YouTube Channel Management
    'https://www.googleapis.com/auth/youtube.channel-memberships.creator',
    'https://www.googleapis.com/auth/youtube.third-party-link.creator'
  ].join(' ')
};

export default config;