export const API_CONFIG = {
  facebook: {
    appId: import.meta.env.VITE_FACEBOOK_APP_ID || '',
    appSecret: import.meta.env.VITE_FACEBOOK_APP_SECRET || '',
    apiVersion: 'v19.0',
    scope: 'pages_show_list,pages_read_engagement,pages_manage_posts,instagram_basic,instagram_content_publish'
  },
  twitter: {
    apiKey: import.meta.env.VITE_TWITTER_API_KEY || '',
    apiSecret: import.meta.env.VITE_TWITTER_API_SECRET || '',
    callbackUrl: `${window.location.origin}/auth/twitter/callback`,
    scope: 'tweet.read tweet.write users.read'
  },
  instagram: {
    clientId: import.meta.env.VITE_INSTAGRAM_CLIENT_ID || '',
    clientSecret: import.meta.env.VITE_INSTAGRAM_CLIENT_SECRET || '',
    scope: 'instagram_basic,instagram_content_publish'
  },
  youtube: {
    apiKey: 'AIzaSyABTBQWQBDdvPGCMLf-yjFd-6fz2UUUmHE',
    clientId: import.meta.env.VITE_YOUTUBE_CLIENT_ID || '',
    clientSecret: import.meta.env.VITE_YOUTUBE_CLIENT_SECRET || '',
    scope: 'https://www.googleapis.com/auth/youtube.readonly https://www.googleapis.com/auth/youtube.upload'
  }
};