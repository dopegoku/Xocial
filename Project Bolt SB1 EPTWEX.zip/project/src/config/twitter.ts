import { APP_URL } from './constants';

const config = {
  apiKey: import.meta.env.VITE_TWITTER_API_KEY,
  apiSecret: import.meta.env.VITE_TWITTER_API_SECRET,
  callbackUrl: `${APP_URL}/auth/twitter/callback`,
  scope: [
    // Read Permissions
    'tweet.read',
    'users.read',
    'follows.read',
    'list.read',
    'space.read',
    
    // Write Permissions
    'tweet.write',
    'tweet.moderate.write',
    'users.write',
    'follows.write',
    'list.write',
    'space.write',
    
    // Direct Message Permissions
    'dm.read',
    'dm.write',
    
    // Media Permissions
    'media.upload',
    'media.upload_longform',
    
    // Analytics Permissions
    'tweet.read.analytics',
    'users.read.analytics',
    
    // Ads Permissions
    'ads.read',
    'ads.write',
    
    // Off-Twitter Activity
    'offline.access'
  ].join(' ')
};

export default config;