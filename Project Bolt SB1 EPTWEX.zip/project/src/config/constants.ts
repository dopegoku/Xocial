// Get the current domain
const getDomain = () => {
  // For WebContainer environment
  if (window.location.hostname.includes('webcontainer.io')) {
    return window.location.origin;
  }
  
  // For local development
  if (import.meta.env.DEV) {
    return 'http://localhost:5173';
  }
  
  // For production
  return 'https://your-production-domain.com';
};

export const APP_URL = getDomain();

// Log the current domain and callback URL for debugging
console.log('Current domain:', APP_URL);
console.log('Facebook callback URL:', `${APP_URL}/auth/facebook/callback`);