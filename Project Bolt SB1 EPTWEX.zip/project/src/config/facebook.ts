import { APP_URL } from './constants';

// Get the current domain for redirect URI
const getDomain = () => {
  // For StackBlitz WebContainer environment
  if (window.location.hostname.includes('webcontainer.io')) {
    return window.location.origin;
  }
  
  // For local development
  if (import.meta.env.DEV) {
    return 'http://localhost:5173';
  }
  
  // For production
  return APP_URL;
};

// Get the current callback URL
const getCallbackUrl = () => {
  const domain = getDomain();
  return `${domain}/auth/facebook/callback`;
};

const config = {
  appId: import.meta.env.VITE_FACEBOOK_APP_ID,
  appSecret: import.meta.env.VITE_FACEBOOK_APP_SECRET,
  version: 'v19.0',
  get domain() {
    return getDomain();
  },
  get callbackUrl() {
    return getCallbackUrl();
  },
  // Start with basic permissions only
  scope: [
    'public_profile',
    'email'
  ].join(','),
  fields: [
    'id',
    'name',
    'email',
    'picture'
  ].join(',')
};

export default config;