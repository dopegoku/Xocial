import React from 'react';
import { cn } from '../../lib/utils';

interface TabsProps {
  value?: string;
  onChange?: (value: string) => void;
  children: React.ReactNode;
  className?: string;
}

export function Tabs({ value, onChange, children, className }: TabsProps) {
  return (
    <div className={cn("flex space-x-1", className)}>
      {React.Children.map(children, (child) => {
        if (React.isValidElement(child)) {
          return React.cloneElement(child, {
            isSelected: child.props.value === value,
            onClick: () => onChange?.(child.props.value),
          });
        }
        return child;
      })}
    </div>
  );
}

interface TabProps {
  value: string;
  isSelected?: boolean;
  onClick?: () => void;
  children: React.ReactNode;
  className?: string;
}

export function Tab({ value, isSelected, onClick, children, className }: TabProps) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "px-4 py-2 text-sm font-medium rounded-md transition-colors",
        isSelected 
          ? "bg-brand-600 text-white" 
          : "text-gray-600 hover:text-gray-900 hover:bg-gray-100 dark:text-gray-400 dark:hover:text-white dark:hover:bg-gray-800",
        className
      )}
    >
      {children}
    </button>
  );
}