import React from 'react';
import { TrendingUp, Users, Eye, MessageCircle, Share2, Video } from 'lucide-react';
import { SocialMetrics } from '../../types';

interface MetricsGridProps {
  platform: string;
  metrics: SocialMetrics;
}

export default function MetricsGrid({ platform, metrics }: MetricsGridProps) {
  const items = [
    {
      label: 'Engagement Rate',
      value: `${metrics.engagement}%`,
      icon: TrendingUp,
      change: '+2.5%',
      color: 'text-green-500',
      bgColor: 'bg-green-50 dark:bg-green-900/20'
    },
    {
      label: 'Total Reach',
      value: metrics.reach.toLocaleString(),
      icon: Eye,
      change: '+5.2%',
      color: 'text-blue-500',
      bgColor: 'bg-blue-50 dark:bg-blue-900/20'
    },
    {
      label: 'Total Posts',
      value: metrics.posts.toLocaleString(),
      icon: Video,
      change: '+1.2%',
      color: 'text-purple-500',
      bgColor: 'bg-purple-50 dark:bg-purple-900/20'
    },
    {
      label: 'Total Likes',
      value: metrics.likes.toLocaleString(),
      icon: Users,
      change: '+3.8%',
      color: 'text-pink-500',
      bgColor: 'bg-pink-50 dark:bg-pink-900/20'
    },
    {
      label: 'Comments',
      value: metrics.comments.toLocaleString(),
      icon: MessageCircle,
      change: '+4.1%',
      color: 'text-orange-500',
      bgColor: 'bg-orange-50 dark:bg-orange-900/20'
    },
    {
      label: 'Shares',
      value: metrics.shares.toLocaleString(),
      icon: Share2,
      change: '+2.9%',
      color: 'text-indigo-500',
      bgColor: 'bg-indigo-50 dark:bg-indigo-900/20'
    },
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
      {items.map((item) => (
        <div
          key={item.label}
          className="bg-white dark:bg-gray-800 p-4 rounded-xl shadow-sm hover:shadow-md transition-shadow"
        >
          <div className="flex items-center justify-between mb-2">
            <div className={`p-2 ${item.bgColor} rounded-lg`}>
              <item.icon className={`w-5 h-5 ${item.color}`} />
            </div>
            <span className={`text-sm ${item.change.startsWith('+') ? 'text-green-500' : 'text-red-500'}`}>
              {item.change}
            </span>
          </div>
          <p className="text-2xl font-bold mb-1">{item.value}</p>
          <p className="text-sm text-gray-500 dark:text-gray-400">{item.label}</p>
        </div>
      ))}
    </div>
  );
}