import React, { useEffect, useState } from 'react';
import { Card, CardHeader, CardContent } from '../ui/Card';
import { getInstagramInsights, getInstagramMedia } from '../../lib/api/facebook';
import EngagementChart from './EngagementChart';
import PerformanceChart from './PerformanceChart';
import MetricsGrid from './MetricsGrid';
import { Loader2 } from 'lucide-react';

interface InstagramInsightsProps {
  igAccountId: string;
  accessToken: string;
}

export default function InstagramInsights({ igAccountId, accessToken }: InstagramInsightsProps) {
  const [insights, setInsights] = useState<any>(null);
  const [media, setMedia] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [insightsData, mediaData] = await Promise.all([
          getInstagramInsights(igAccountId, accessToken),
          getInstagramMedia(igAccountId, accessToken)
        ]);
        setInsights(insightsData);
        setMedia(mediaData);
      } catch (error) {
        console.error('Failed to fetch Instagram insights:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, [igAccountId, accessToken]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center p-8">
        <Loader2 className="w-8 h-8 animate-spin text-purple-500" />
      </div>
    );
  }

  if (!insights) {
    return null;
  }

  // Process insights data for charts
  const reachData = insights.find((i: any) => i.name === 'reach')?.values || [];
  const impressionsData = insights.find((i: any) => i.name === 'impressions')?.values || [];

  // Calculate engagement rate from media data
  const totalEngagements = media.reduce((sum, post) => sum + (post.like_count + post.comments_count), 0);
  const engagementRate = (totalEngagements / (media.length || 1)) / (parseInt(reachData[0]?.value || '1')) * 100;

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <h3 className="text-lg font-semibold">Instagram Performance</h3>
        </CardHeader>
        <CardContent>
          <MetricsGrid
            platform="instagram"
            metrics={{
              reach: parseInt(reachData[0]?.value || '0'),
              engagement: parseFloat(engagementRate.toFixed(2)),
              likes: media.reduce((sum, post) => sum + post.like_count, 0),
              comments: media.reduce((sum, post) => sum + post.comments_count, 0),
              shares: 0,
              posts: media.length
            }}
          />
        </CardContent>
      </Card>

      <div className="grid md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <h3 className="text-lg font-semibold">Account Reach</h3>
          </CardHeader>
          <CardContent>
            <PerformanceChart
              platform="instagram"
              data={{
                labels: reachData.map((d: any) => new Date(d.end_time).toLocaleDateString()),
                values: reachData.map((d: any) => d.value)
              }}
              title="Daily Reach"
            />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <h3 className="text-lg font-semibold">Impressions</h3>
          </CardHeader>
          <CardContent>
            <PerformanceChart
              platform="instagram"
              data={{
                labels: impressionsData.map((d: any) => new Date(d.end_time).toLocaleDateString()),
                values: impressionsData.map((d: any) => d.value)
              }}
              title="Daily Impressions"
            />
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <h3 className="text-lg font-semibold">Recent Posts Performance</h3>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {media.slice(0, 8).map((post: any) => (
              <div key={post.id} className="space-y-2">
                <img
                  src={post.media_url}
                  alt={post.caption}
                  className="w-full aspect-square object-cover rounded-lg"
                />
                <div className="text-sm">
                  <p className="font-medium">Likes: {post.like_count}</p>
                  <p className="text-gray-500">Comments: {post.comments_count}</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}