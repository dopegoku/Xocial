import React, { useEffect, useState } from 'react';
import { Card, CardHeader, CardContent } from '../ui/Card';
import { getPageInsights } from '../../lib/api/facebook';
import EngagementChart from './EngagementChart';
import PerformanceChart from './PerformanceChart';
import MetricsGrid from './MetricsGrid';
import { Loader2 } from 'lucide-react';

interface FacebookInsightsProps {
  pageId: string;
  accessToken: string;
}

export default function FacebookInsights({ pageId, accessToken }: FacebookInsightsProps) {
  const [insights, setInsights] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchInsights = async () => {
      try {
        const data = await getPageInsights(pageId, accessToken);
        setInsights(data);
      } catch (error) {
        console.error('Failed to fetch Facebook insights:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchInsights();
  }, [pageId, accessToken]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center p-8">
        <Loader2 className="w-8 h-8 animate-spin text-purple-500" />
      </div>
    );
  }

  if (!insights) {
    return null;
  }

  // Process insights data for charts
  const impressionsData = insights.find((i: any) => i.name === 'page_impressions')?.values || [];
  const engagementData = insights.find((i: any) => i.name === 'page_engaged_users')?.values || [];

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <h3 className="text-lg font-semibold">Page Performance</h3>
        </CardHeader>
        <CardContent>
          <MetricsGrid
            platform="facebook"
            metrics={{
              reach: parseInt(impressionsData[0]?.value || '0'),
              engagement: parseFloat(((parseInt(engagementData[0]?.value || '0') / parseInt(impressionsData[0]?.value || '1')) * 100).toFixed(2)),
              likes: 0,
              comments: 0,
              shares: 0,
              posts: 0
            }}
          />
        </CardContent>
      </Card>

      <div className="grid md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <h3 className="text-lg font-semibold">Page Impressions</h3>
          </CardHeader>
          <CardContent>
            <PerformanceChart
              platform="facebook"
              data={{
                labels: impressionsData.map((d: any) => new Date(d.end_time).toLocaleDateString()),
                values: impressionsData.map((d: any) => d.value)
              }}
              title="Daily Impressions"
            />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <h3 className="text-lg font-semibold">Engagement Rate</h3>
          </CardHeader>
          <CardContent>
            <EngagementChart
              platform="facebook"
              data={engagementData.map((d: any) => 
                parseFloat(((d.value / impressionsData.find((i: any) => i.end_time === d.end_time)?.value || 1) * 100).toFixed(2))
              )}
            />
          </CardContent>
        </Card>
      </div>
    </div>
  );
}