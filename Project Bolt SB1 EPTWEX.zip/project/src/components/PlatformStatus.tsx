import React from 'react';
import { Check, Loader2, Link2 } from 'lucide-react';
import { useSocialAccountsStore } from '../store/useSocialAccountsStore';
import { useYouTubeAuth } from '../hooks/useYouTubeAuth';
import { useFacebookAuth } from '../hooks/useFacebookAuth';
import type { SocialPlatform } from '../types';
import toast from 'react-hot-toast';

const platformConfig = {
  facebook: {
    name: 'Facebook',
    color: 'text-blue-600 dark:text-blue-400',
    bgColor: 'bg-blue-100 dark:bg-blue-900/50'
  },
  instagram: {
    name: 'Instagram',
    color: 'text-pink-600 dark:text-pink-400',
    bgColor: 'bg-pink-100 dark:bg-pink-900/50'
  },
  youtube: {
    name: 'YouTube',
    color: 'text-red-600 dark:text-red-400',
    bgColor: 'bg-red-100 dark:bg-red-900/50'
  },
  twitter: {
    name: 'Twitter',
    color: 'text-sky-600 dark:text-sky-400',
    bgColor: 'bg-sky-100 dark:bg-sky-900/50'
  }
};

export default function PlatformStatus() {
  const { accounts } = useSocialAccountsStore();
  const { authenticate: connectYouTube, isAuthenticating: isYouTubeConnecting } = useYouTubeAuth();
  const { authenticate: connectFacebook, isAuthenticating: isFacebookConnecting } = useFacebookAuth();

  const handleConnect = async (platform: SocialPlatform) => {
    try {
      switch (platform) {
        case 'youtube':
          await connectYouTube();
          break;
        case 'facebook':
        case 'instagram':
          await connectFacebook();
          break;
        case 'twitter':
          toast.error('Twitter integration coming soon');
          break;
      }
    } catch (error) {
      console.error(`${platform} connection error:`, error);
    }
  };

  const isConnecting = (platform: SocialPlatform) => {
    switch (platform) {
      case 'youtube':
        return isYouTubeConnecting;
      case 'facebook':
      case 'instagram':
        return isFacebookConnecting;
      default:
        return false;
    }
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm">
      <h3 className="text-lg font-semibold mb-4">Platform Status</h3>
      <div className="space-y-4">
        {Object.entries(platformConfig).map(([platform, config]) => {
          const account = accounts.find(acc => acc.platform === platform);
          const connecting = isConnecting(platform as SocialPlatform);

          return (
            <div key={platform} className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className={`w-2 h-2 rounded-full ${account ? 'bg-green-500' : 'bg-red-500'}`} />
                <span className="font-medium">{config.name}</span>
              </div>
              <div className="flex items-center space-x-2">
                {account ? (
                  <span className="text-sm text-green-500 flex items-center">
                    <Check className="w-4 h-4 mr-1" />
                    Connected
                  </span>
                ) : (
                  <button
                    onClick={() => handleConnect(platform as SocialPlatform)}
                    disabled={connecting}
                    className={`flex items-center space-x-1 text-sm ${config.color} hover:opacity-80 disabled:opacity-50`}
                  >
                    {connecting ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        <span>Connecting...</span>
                      </>
                    ) : (
                      <>
                        <Link2 className="w-4 h-4" />
                        <span>Connect</span>
                      </>
                    )}
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}