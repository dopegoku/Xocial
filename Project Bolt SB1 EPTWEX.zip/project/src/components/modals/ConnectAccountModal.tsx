import React, { useState } from 'react';
import { Instagram, Facebook, Twitter, Youtube, X, Loader2 } from 'lucide-react';
import { useFacebookAuth } from '../../hooks/useFacebookAuth';
import { useYouTubeAuth } from '../../hooks/useYouTubeAuth';
import toast from 'react-hot-toast';
import type { SocialPlatform } from '../../types';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

const platforms = [
  { id: 'facebook', name: 'Facebook', icon: Facebook, color: 'hover:bg-blue-50 dark:hover:bg-blue-900/20' },
  { id: 'instagram', name: 'Instagram', icon: Instagram, color: 'hover:bg-pink-50 dark:hover:bg-pink-900/20' },
  { id: 'twitter', name: 'Twitter', icon: Twitter, color: 'hover:bg-sky-50 dark:hover:bg-sky-900/20' },
  { id: 'youtube', name: 'YouTube', icon: Youtube, color: 'hover:bg-red-50 dark:hover:bg-red-900/20' },
] as const;

export default function ConnectAccountModal({ isOpen, onClose, onSuccess }: Props) {
  const [connecting, setConnecting] = useState<SocialPlatform | null>(null);
  const { authenticate: authenticateYouTube, isAuthenticating: isYouTubeAuthenticating } = useYouTubeAuth();
  const { authenticate: authenticateFacebook, isAuthenticating: isFacebookAuthenticating } = useFacebookAuth();

  if (!isOpen) return null;

  const handleConnect = async (platform: SocialPlatform) => {
    try {
      setConnecting(platform);
      
      switch (platform) {
        case 'youtube':
          await authenticateYouTube();
          break;
        case 'facebook':
        case 'instagram':
          await authenticateFacebook();
          break;
        case 'twitter':
          toast.error('Twitter integration coming soon');
          return;
      }
      
      onSuccess();
    } catch (error) {
      console.error(`${platform} connection error:`, error);
    } finally {
      setConnecting(null);
    }
  };

  const isConnecting = (platform: SocialPlatform) => {
    switch (platform) {
      case 'youtube':
        return isYouTubeAuthenticating;
      case 'facebook':
      case 'instagram':
        return isFacebookAuthenticating;
      default:
        return false;
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-white dark:bg-gray-800 rounded-xl w-full max-w-md p-6">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-xl font-semibold">Connect Account</h3>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-4">
          {platforms.map(({ id, name, icon: Icon, color }) => (
            <button
              key={id}
              onClick={() => handleConnect(id as SocialPlatform)}
              disabled={connecting === id || isConnecting(id as SocialPlatform)}
              className={`w-full p-4 rounded-lg border border-gray-200 dark:border-gray-700 ${color} flex items-center justify-between`}
            >
              <div className="flex items-center space-x-3">
                <Icon className="w-6 h-6" />
                <span className="font-medium">{name}</span>
              </div>
              {isConnecting(id as SocialPlatform) ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                <span className="text-sm text-gray-500">Connect</span>
              )}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}