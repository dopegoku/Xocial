import React from 'react';
import { ArrowUpRight, ArrowDownRight } from 'lucide-react';
import type { SocialMetrics } from '../types';

interface MetricsCardProps {
  platform: string;
  metrics: SocialMetrics;
  change: number;
  icon: React.ReactNode;
}

export default function MetricsCard({ platform, metrics, change, icon }: MetricsCardProps) {
  const isPositive = change >= 0;

  return (
    <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 shadow-sm hover:shadow-md transition-shadow duration-200">
      <div className="flex items-center justify-between mb-4">
        <div className="p-3 bg-purple-100 dark:bg-purple-900/50 rounded-xl">
          {icon}
        </div>
        <span className={`flex items-center text-sm ${
          isPositive ? 'text-green-600' : 'text-red-600'
        }`}>
          {isPositive ? <ArrowUpRight className="w-4 h-4" /> : <ArrowDownRight className="w-4 h-4" />}
          {Math.abs(change)}%
        </span>
      </div>
      
      <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-1 capitalize">{platform}</h3>
      
      <div className="grid grid-cols-2 gap-4 mt-4">
        <div>
          <p className="text-sm text-gray-500 dark:text-gray-400">Engagement</p>
          <p className="text-xl font-semibold text-gray-900 dark:text-white">
            {metrics.engagement.toLocaleString()}%
          </p>
        </div>
        <div>
          <p className="text-sm text-gray-500 dark:text-gray-400">Reach</p>
          <p className="text-xl font-semibold text-gray-900 dark:text-white">
            {metrics.reach.toLocaleString()}
          </p>
        </div>
        <div>
          <p className="text-sm text-gray-500 dark:text-gray-400">Posts</p>
          <p className="text-xl font-semibold text-gray-900 dark:text-white">
            {metrics.posts.toLocaleString()}
          </p>
        </div>
        <div>
          <p className="text-sm text-gray-500 dark:text-gray-400">Total Interactions</p>
          <p className="text-xl font-semibold text-gray-900 dark:text-white">
            {(metrics.likes + metrics.comments + metrics.shares).toLocaleString()}
          </p>
        </div>
      </div>
    </div>
  );
}