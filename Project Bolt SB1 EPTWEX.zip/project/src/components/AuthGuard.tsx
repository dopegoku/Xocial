import React, { useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useAuthStore } from '../store/useAuthStore';
import { getCurrentUser } from '../lib/api/auth';
import { Loader2 } from 'lucide-react';

interface AuthGuardProps {
  children: React.ReactNode;
}

export default function AuthGuard({ children }: AuthGuardProps) {
  const navigate = useNavigate();
  const location = useLocation();
  const { isAuthenticated, isLoading, login, setLoading } = useAuthStore();

  useEffect(() => {
    const checkAuth = async () => {
      try {
        const user = await getCurrentUser();
        if (user) {
          login(user);
          if (!user.onboardingCompleted && location.pathname !== '/onboarding') {
            navigate('/onboarding');
          }
        } else if (!isPublicRoute(location.pathname)) {
          navigate('/signin');
        }
      } catch (error) {
        if (!isPublicRoute(location.pathname)) {
          navigate('/signin');
        }
      } finally {
        setLoading(false);
      }
    };

    checkAuth();
  }, [location.pathname]);

  if (isLoading && !isPublicRoute(location.pathname)) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-brand-600" />
      </div>
    );
  }

  // Redirect authenticated users away from auth pages
  if (isAuthenticated && isPublicRoute(location.pathname)) {
    return <Navigate to="/" replace />;
  }

  return <>{children}</>;
}

function isPublicRoute(pathname: string): boolean {
  return ['/signin', '/signup', '/auth/google/callback'].includes(pathname);
}