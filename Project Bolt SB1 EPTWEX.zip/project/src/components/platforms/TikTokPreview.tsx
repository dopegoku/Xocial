import React from 'react';
import { Heart, MessageCircle, Bookmark, Share2, Music } from 'lucide-react';

interface TikTokPreviewProps {
  content: string;
  media: string[];
  username: string;
  avatar: string;
  songName?: string;
}

export default function TikTokPreview({ content, media, username, avatar, songName = "Original Sound" }: TikTokPreviewProps) {
  return (
    <div className="w-[320px] h-[640px] bg-black rounded-xl overflow-hidden relative">
      {media[0] && (
        <video 
          src={media[0]} 
          className="w-full h-full object-cover"
          loop
          muted
          autoPlay
        />
      )}
      
      <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/60 to-transparent">
        <div className="mb-4">
          <p className="text-white font-medium mb-2">@{username}</p>
          <p className="text-white text-sm">{content}</p>
          <div className="flex items-center space-x-2 mt-2">
            <Music className="w-4 h-4 text-white" />
            <p className="text-white text-sm">{songName}</p>
          </div>
        </div>
      </div>

      <div className="absolute right-4 bottom-20 flex flex-col items-center space-y-6">
        <div className="flex flex-col items-center">
          <img src={avatar} alt={username} className="w-12 h-12 rounded-full border-2 border-white mb-1" />
          <button className="bg-red-500 text-white text-xs rounded-full px-2 py-1">Follow</button>
        </div>
        
        <div className="flex flex-col items-center">
          <Heart className="w-8 h-8 text-white mb-1" />
          <span className="text-white text-xs">0</span>
        </div>
        
        <div className="flex flex-col items-center">
          <MessageCircle className="w-8 h-8 text-white mb-1" />
          <span className="text-white text-xs">0</span>
        </div>
        
        <div className="flex flex-col items-center">
          <Bookmark className="w-8 h-8 text-white mb-1" />
          <span className="text-white text-xs">0</span>
        </div>
        
        <div className="flex flex-col items-center">
          <Share2 className="w-8 h-8 text-white mb-1" />
          <span className="text-white text-xs">0</span>
        </div>
      </div>
    </div>
  );
}