import React from 'react';
import { MessageCircle, Repeat2, Heart, BarChart2, Share, MoreHorizontal } from 'lucide-react';
import { formatRelativeTime } from '../../lib/utils';

interface TwitterPreviewProps {
  content: string;
  media: string[];
  username: string;
  handle: string;
  avatar: string;
}

export default function TwitterPreview({ content, media, username, handle, avatar }: TwitterPreviewProps) {
  return (
    <div className="w-[468px] bg-white dark:bg-gray-900 rounded-xl overflow-hidden border border-gray-200 dark:border-gray-700">
      <div className="p-4">
        <div className="flex justify-between">
          <div className="flex space-x-3">
            <img src={avatar} alt={username} className="w-12 h-12 rounded-full" />
            <div>
              <div className="flex items-center space-x-1">
                <span className="font-bold">{username}</span>
                <span className="text-gray-500">@{handle}</span>
                <span className="text-gray-500">•</span>
                <span className="text-gray-500">{formatRelativeTime(new Date())}</span>
              </div>
              <p className="mt-1">{content}</p>
              
              {media[0] && (
                <div className="mt-3 rounded-xl overflow-hidden">
                  <img 
                    src={media[0]} 
                    alt="Tweet media"
                    className="w-full h-full object-cover"
                  />
                </div>
              )}
              
              <div className="flex items-center justify-between mt-3 text-gray-500">
                <button className="flex items-center space-x-2 hover:text-blue-500">
                  <MessageCircle className="w-5 h-5" />
                  <span>0</span>
                </button>
                <button className="flex items-center space-x-2 hover:text-green-500">
                  <Repeat2 className="w-5 h-5" />
                  <span>0</span>
                </button>
                <button className="flex items-center space-x-2 hover:text-red-500">
                  <Heart className="w-5 h-5" />
                  <span>0</span>
                </button>
                <button className="flex items-center space-x-2 hover:text-blue-500">
                  <BarChart2 className="w-5 h-5" />
                  <span>0</span>
                </button>
                <button className="hover:text-blue-500">
                  <Share className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>
          <MoreHorizontal className="w-5 h-5 text-gray-500" />
        </div>
      </div>
    </div>
  );
}