import React from 'react';
import { Share2, MoreHorizontal, ExternalLink } from 'lucide-react';

interface PinterestPreviewProps {
  content: string;
  media: string[];
  username: string;
  avatar: string;
  boardName?: string;
}

export default function PinterestPreview({ content, media, username, avatar, boardName = "My Board" }: PinterestPreviewProps) {
  return (
    <div className="w-[320px] bg-white dark:bg-gray-900 rounded-2xl overflow-hidden shadow-lg">
      <div className="relative">
        {media[0] && (
          <img 
            src={media[0]} 
            alt="Pin"
            className="w-full aspect-[3/4] object-cover"
          />
        )}
        
        <div className="absolute top-4 right-4 flex space-x-2">
          <button className="bg-gray-100/90 hover:bg-gray-200/90 p-2 rounded-full">
            <Share2 className="w-5 h-5" />
          </button>
          <button className="bg-gray-100/90 hover:bg-gray-200/90 p-2 rounded-full">
            <MoreHorizontal className="w-5 h-5" />
          </button>
        </div>
        
        <button className="absolute bottom-4 left-4 bg-red-500 text-white px-4 py-2 rounded-full font-medium hover:bg-red-600">
          Save
        </button>
      </div>
      
      <div className="p-4">
        <h3 className="font-medium mb-2">{content}</h3>
        
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <img src={avatar} alt={username} className="w-8 h-8 rounded-full" />
            <div>
              <p className="text-sm font-medium">{username}</p>
              <p className="text-xs text-gray-500">{boardName}</p>
            </div>
          </div>
          
          <button className="text-gray-500 hover:text-gray-700">
            <ExternalLink className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
}