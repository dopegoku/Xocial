import React from 'react';
import { ThumbsUp, MessageCircle, Share2, Globe, MoreHorizontal } from 'lucide-react';
import { formatRelativeTime } from '../../lib/utils';

interface FacebookPreviewProps {
  content: string;
  media: string[];
  username: string;
  avatar: string;
  isStory?: boolean;
}

export default function FacebookPreview({ content, media, username, avatar, isStory }: FacebookPreviewProps) {
  if (isStory) {
    return (
      <div className="w-[360px] h-[640px] bg-black rounded-xl overflow-hidden relative">
        {media[0] && (
          <img 
            src={media[0]} 
            alt="Story preview"
            className="w-full h-full object-cover"
          />
        )}
        <div className="absolute top-0 left-0 right-0 p-4 flex items-center space-x-2">
          <img src={avatar} alt={username} className="w-8 h-8 rounded-full border-2 border-white" />
          <span className="text-white font-medium">{username}</span>
        </div>
      </div>
    );
  }

  return (
    <div className="w-[500px] bg-white dark:bg-gray-900 rounded-xl overflow-hidden border border-gray-200 dark:border-gray-700">
      <div className="p-4">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center space-x-2">
            <img src={avatar} alt={username} className="w-10 h-10 rounded-full" />
            <div>
              <p className="font-medium">{username}</p>
              <div className="flex items-center space-x-1 text-sm text-gray-500">
                <span>{formatRelativeTime(new Date())}</span>
                <span>•</span>
                <Globe className="w-3 h-3" />
              </div>
            </div>
          </div>
          <MoreHorizontal className="w-5 h-5 text-gray-500" />
        </div>
        
        <p className="mb-3">{content}</p>
        
        {media[0] && (
          <div className="relative -mx-4">
            <img 
              src={media[0]} 
              alt="Post preview"
              className="w-full"
            />
          </div>
        )}
        
        <div className="mt-3 pt-3 border-t border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between">
            <button className="flex items-center space-x-2 text-gray-600 hover:text-gray-800">
              <ThumbsUp className="w-5 h-5" />
              <span>Like</span>
            </button>
            <button className="flex items-center space-x-2 text-gray-600 hover:text-gray-800">
              <MessageCircle className="w-5 h-5" />
              <span>Comment</span>
            </button>
            <button className="flex items-center space-x-2 text-gray-600 hover:text-gray-800">
              <Share2 className="w-5 h-5" />
              <span>Share</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}