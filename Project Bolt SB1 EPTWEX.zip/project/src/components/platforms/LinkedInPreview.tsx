import React from 'react';
import { ThumbsUp, MessageSquare, Share2, Send } from 'lucide-react';
import { formatRelativeTime } from '../../lib/utils';

interface LinkedInPreviewProps {
  content: string;
  media: string[];
  username: string;
  title?: string;
  avatar: string;
  company?: string;
}

export default function LinkedInPreview({ content, media, username, title = "Marketing Manager", avatar, company = "Your Company" }: LinkedInPreviewProps) {
  return (
    <div className="w-[552px] bg-white dark:bg-gray-900 rounded-xl overflow-hidden border border-gray-200 dark:border-gray-700">
      <div className="p-4">
        <div className="flex items-start space-x-3 mb-3">
          <img src={avatar} alt={username} className="w-12 h-12 rounded-full" />
          <div>
            <p className="font-medium">{username}</p>
            <p className="text-sm text-gray-600 dark:text-gray-400">{title} at {company}</p>
            <p className="text-sm text-gray-500">{formatRelativeTime(new Date())}</p>
          </div>
        </div>

        <p className="mb-4">{content}</p>

        {media[0] && (
          <div className="mb-4">
            <img 
              src={media[0]} 
              alt="Post media"
              className="w-full rounded-lg"
            />
          </div>
        )}

        <div className="flex items-center justify-between pt-3 border-t border-gray-200 dark:border-gray-700">
          <button className="flex items-center space-x-1 text-gray-600 hover:text-blue-600">
            <ThumbsUp className="w-5 h-5" />
            <span>Like</span>
          </button>
          <button className="flex items-center space-x-1 text-gray-600 hover:text-blue-600">
            <MessageSquare className="w-5 h-5" />
            <span>Comment</span>
          </button>
          <button className="flex items-center space-x-1 text-gray-600 hover:text-blue-600">
            <Share2 className="w-5 h-5" />
            <span>Share</span>
          </button>
          <button className="flex items-center space-x-1 text-gray-600 hover:text-blue-600">
            <Send className="w-5 h-5" />
            <span>Send</span>
          </button>
        </div>
      </div>
    </div>
  );
}