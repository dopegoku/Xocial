import React from 'react';
import { Camera, MessageCircle, Map, Image, Ghost } from 'lucide-react';

interface SnapchatPreviewProps {
  content: string;
  media: string[];
  username: string;
  avatar: string;
  isStory?: boolean;
}

export default function SnapchatPreview({ content, media, username, avatar, isStory }: SnapchatPreviewProps) {
  return (
    <div className="w-[360px] h-[640px] bg-black rounded-xl overflow-hidden relative">
      {media[0] && (
        <div className="relative h-full">
          <img 
            src={media[0]} 
            alt="Snap preview"
            className="w-full h-full object-cover"
          />
          
          {!isStory && (
            <div className="absolute top-4 right-4 flex space-x-4">
              <button className="text-white">
                <Camera className="w-6 h-6" />
              </button>
              <button className="text-white">
                <Image className="w-6 h-6" />
              </button>
            </div>
          )}
          
          {content && (
            <div className="absolute bottom-20 left-0 right-0 p-4 text-center">
              <p className="text-white text-lg font-bold bg-black/50 p-2 rounded">
                {content}
              </p>
            </div>
          )}
        </div>
      )}
      
      {!isStory && (
        <div className="absolute bottom-0 left-0 right-0 flex justify-around p-4 bg-black/20">
          <button className="text-white flex flex-col items-center">
            <Map className="w-6 h-6" />
            <span className="text-xs mt-1">Map</span>
          </button>
          <button className="text-white flex flex-col items-center">
            <MessageCircle className="w-6 h-6" />
            <span className="text-xs mt-1">Chat</span>
          </button>
          <button className="text-white flex flex-col items-center">
            <Camera className="w-6 h-6" />
            <span className="text-xs mt-1">Camera</span>
          </button>
          <button className="text-white flex flex-col items-center">
            <Image className="w-6 h-6" />
            <span className="text-xs mt-1">Stories</span>
          </button>
          <button className="text-white flex flex-col items-center">
            <Ghost className="w-6 h-6" />
            <span className="text-xs mt-1">Spotlight</span>
          </button>
        </div>
      )}
    </div>
  );
}