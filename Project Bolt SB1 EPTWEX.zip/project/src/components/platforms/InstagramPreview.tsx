import React from 'react';
import { Heart, MessageCircle, Bookmark, Send, MoreHorizontal } from 'lucide-react';
import { formatRelativeTime } from '../../lib/utils';

interface InstagramPreviewProps {
  content: string;
  media: string[];
  username: string;
  avatar: string;
  isStory?: boolean;
  isReel?: boolean;
}

export default function InstagramPreview({ content, media, username, avatar, isStory, isReel }: InstagramPreviewProps) {
  if (isStory) {
    return (
      <div className="w-[360px] h-[640px] bg-black rounded-xl overflow-hidden relative">
        {media[0] && (
          <img 
            src={media[0]} 
            alt="Story preview"
            className="w-full h-full object-cover"
          />
        )}
        <div className="absolute top-0 left-0 right-0 p-4 flex items-center space-x-2">
          <img src={avatar} alt={username} className="w-8 h-8 rounded-full border-2 border-white" />
          <span className="text-white font-medium">{username}</span>
        </div>
      </div>
    );
  }

  if (isReel) {
    return (
      <div className="w-[360px] h-[640px] bg-black rounded-xl overflow-hidden relative">
        {media[0] && (
          <video 
            src={media[0]} 
            className="w-full h-full object-cover"
            loop
            muted
            autoPlay
          />
        )}
        <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/60 to-transparent">
          <div className="flex items-center space-x-2 mb-2">
            <img src={avatar} alt={username} className="w-8 h-8 rounded-full" />
            <span className="text-white font-medium">{username}</span>
          </div>
          <p className="text-white text-sm">{content}</p>
        </div>
        <div className="absolute right-4 bottom-20 flex flex-col items-center space-y-6">
          <Heart className="w-7 h-7 text-white" />
          <MessageCircle className="w-7 h-7 text-white" />
          <Bookmark className="w-7 h-7 text-white" />
          <Send className="w-7 h-7 text-white" />
        </div>
      </div>
    );
  }

  return (
    <div className="w-[468px] bg-white dark:bg-gray-900 rounded-xl overflow-hidden border border-gray-200 dark:border-gray-700">
      <div className="p-3 flex items-center justify-between border-b border-gray-200 dark:border-gray-700">
        <div className="flex items-center space-x-2">
          <img src={avatar} alt={username} className="w-8 h-8 rounded-full" />
          <span className="font-medium">{username}</span>
        </div>
        <MoreHorizontal className="w-5 h-5 text-gray-500" />
      </div>
      
      {media[0] && (
        <div className="aspect-square bg-black">
          <img 
            src={media[0]} 
            alt="Post preview"
            className="w-full h-full object-cover"
          />
        </div>
      )}
      
      <div className="p-3">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center space-x-4">
            <Heart className="w-6 h-6" />
            <MessageCircle className="w-6 h-6" />
            <Send className="w-6 h-6" />
          </div>
          <Bookmark className="w-6 h-6" />
        </div>
        
        <div className="space-y-1">
          <p>
            <span className="font-medium mr-2">{username}</span>
            {content}
          </p>
          <p className="text-sm text-gray-500 dark:text-gray-400">
            {formatRelativeTime(new Date())}
          </p>
        </div>
      </div>
    </div>
  );
}