import React from 'react';
import { ThumbsUp, ThumbsDown, Share2, MoreVertical } from 'lucide-react';

interface YouTubePreviewProps {
  title: string;
  description: string;
  thumbnail: string;
  username: string;
  avatar: string;
  isShort?: boolean;
}

export default function YouTubePreview({ title, description, thumbnail, username, avatar, isShort }: YouTubePreviewProps) {
  if (isShort) {
    return (
      <div className="w-[360px] h-[640px] bg-black rounded-xl overflow-hidden relative">
        <img 
          src={thumbnail} 
          alt="YouTube Short preview"
          className="w-full h-full object-cover"
        />
        <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/60 to-transparent">
          <h3 className="text-white font-medium mb-1">{title}</h3>
          <div className="flex items-center space-x-2">
            <img src={avatar} alt={username} className="w-6 h-6 rounded-full" />
            <span className="text-white text-sm">{username}</span>
          </div>
        </div>
        <div className="absolute right-4 bottom-20 flex flex-col items-center space-y-6">
          <ThumbsUp className="w-7 h-7 text-white" />
          <ThumbsDown className="w-7 h-7 text-white" />
          <Share2 className="w-7 h-7 text-white" />
          <MoreVertical className="w-7 h-7 text-white" />
        </div>
      </div>
    );
  }

  return (
    <div className="w-[640px] bg-white dark:bg-gray-900 rounded-xl overflow-hidden border border-gray-200 dark:border-gray-700">
      <div className="aspect-video bg-black">
        <img 
          src={thumbnail} 
          alt="Video thumbnail"
          className="w-full h-full object-cover"
        />
      </div>
      
      <div className="p-4">
        <div className="flex items-start justify-between">
          <div className="flex space-x-3">
            <img src={avatar} alt={username} className="w-10 h-10 rounded-full" />
            <div>
              <h3 className="font-medium">{title}</h3>
              <p className="text-sm text-gray-500 dark:text-gray-400">{username}</p>
              <p className="text-sm text-gray-500 dark:text-gray-400 mt-2">{description}</p>
            </div>
          </div>
          <MoreVertical className="w-5 h-5 text-gray-500" />
        </div>
        
        <div className="flex items-center space-x-4 mt-4">
          <button className="flex items-center space-x-1">
            <ThumbsUp className="w-5 h-5" />
            <span>0</span>
          </button>
          <button className="flex items-center space-x-1">
            <ThumbsDown className="w-5 h-5" />
            <span>0</span>
          </button>
          <button className="flex items-center space-x-1">
            <Share2 className="w-5 h-5" />
            <span>Share</span>
          </button>
        </div>
      </div>
    </div>
  );
}