import React from 'react';
import { useLocation, useNavigate, Outlet } from 'react-router-dom';
import { Home, Calendar, BarChart2, Users, Settings, LogOut, Video, Facebook } from 'lucide-react';
import { useAuthStore } from '../store/useAuthStore';
import { signOut } from '../lib/api/auth';
import toast from 'react-hot-toast';
import ThemeToggle from './ThemeToggle';
import NotificationCenter from './NotificationCenter';

export default function Layout() {
  const location = useLocation();
  const navigate = useNavigate();
  const { logout } = useAuthStore();

  const tabs = [
    { path: '/', label: 'Dashboard', icon: Home },
    { path: '/schedule', label: 'Schedule', icon: Calendar },
    { path: '/analytics', label: 'Analytics', icon: BarChart2 },
    { path: '/team', label: 'Team', icon: Users },
    { path: '/settings', label: 'Settings', icon: Settings },
    { path: '/youtube-test', label: 'YouTube Test', icon: Video },
    { path: '/facebook-test', label: 'Facebook Test', icon: Facebook },
  ];

  const isCurrentPath = (path: string) => {
    if (path === '/') {
      return location.pathname === '/';
    }
    return location.pathname.startsWith(path);
  };

  const handleSignOut = async () => {
    try {
      await signOut();
      logout();
      toast.success('Signed out successfully');
      navigate('/signin');
    } catch (error) {
      toast.error('Failed to sign out');
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <header className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 fixed top-0 left-0 right-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <span 
                className="text-2xl font-bold text-brand-600 cursor-pointer"
                onClick={() => navigate('/')}
              >
                PostIT
              </span>
            </div>
            <div className="flex items-center space-x-4">
              <NotificationCenter />
              <ThemeToggle />
              <button
                onClick={handleSignOut}
                className="flex items-center space-x-2 text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
              >
                <LogOut className="w-5 h-5" />
                <span className="hidden sm:inline">Sign Out</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 z-50">
        <div className="max-w-7xl mx-auto px-4">
          <nav className="flex justify-around">
            {tabs.map(({ path, label, icon: Icon }) => (
              <button
                key={path}
                onClick={() => navigate(path)}
                className={`flex flex-col items-center py-3 px-4 transition-colors ${
                  isCurrentPath(path)
                    ? 'text-brand-600'
                    : 'text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200'
                }`}
              >
                <Icon className="w-6 h-6" />
                <span className="text-xs mt-1">{label}</span>
              </button>
            ))}
          </nav>
        </div>
      </div>

      <main className="pt-16 pb-20 p-4">
        <div className="max-w-7xl mx-auto">
          <Outlet />
        </div>
      </main>
    </div>
  );
}