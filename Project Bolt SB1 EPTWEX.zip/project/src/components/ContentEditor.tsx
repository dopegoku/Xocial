import React, { useState } from 'react';
import { Card, CardHeader, CardContent } from './ui/Card';
import { Tabs, Tab } from './ui/Tabs';
import Button from './ui/Button';
import { Image, Video, Calendar, Upload } from 'lucide-react';
import { useDropzone } from 'react-dropzone';
import YouTubePreview from './platforms/YouTubePreview';
import { uploadYouTubeVideo } from '../lib/api/youtube';
import toast from 'react-hot-toast';

export default function ContentEditor() {
  const [selectedTab, setSelectedTab] = useState('youtube');
  const [files, setFiles] = useState<File[]>([]);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [isUploading, setIsUploading] = useState(false);

  const { getRootProps, getInputProps } = useDropzone({
    accept: {
      'video/*': ['.mp4', '.mov']
    },
    maxFiles: 1,
    onDrop: acceptedFiles => {
      setFiles(acceptedFiles);
    }
  });

  const handleUpload = async () => {
    if (!files[0] || !title) {
      toast.error('Please provide a video and title');
      return;
    }

    setIsUploading(true);
    try {
      await uploadYouTubeVideo(files[0], title, description);
      toast.success('Video uploaded successfully!');
      setFiles([]);
      setTitle('');
      setDescription('');
    } catch (error) {
      toast.error('Failed to upload video');
      console.error('Upload error:', error);
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <h3 className="text-lg font-semibold">Create YouTube Content</h3>
        </CardHeader>
        <CardContent>
          <Tabs value={selectedTab} onChange={setSelectedTab}>
            <Tab value="youtube">Video</Tab>
            <Tab value="shorts">Shorts</Tab>
          </Tabs>

          <div className="mt-6 space-y-4">
            <input
              type="text"
              placeholder="Video title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full p-2 border rounded-md"
            />

            <textarea
              placeholder="Video description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full p-2 border rounded-md h-24"
            />

            <div
              {...getRootProps()}
              className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-6 text-center cursor-pointer hover:border-purple-500 transition-colors"
            >
              <input {...getInputProps()} />
              <div className="space-y-2">
                <div className="flex justify-center">
                  <Video className="w-12 h-12 text-gray-400" />
                </div>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Drag & drop or click to upload video
                </p>
                <p className="text-xs text-gray-500">
                  {selectedTab === 'shorts' ? 'Max duration: 60 seconds' : 'Max size: 128GB'}
                </p>
              </div>
            </div>

            {files[0] && (
              <div className="mt-4">
                <YouTubePreview
                  title={title}
                  description={description}
                  thumbnail={URL.createObjectURL(files[0])}
                  username="Your Channel"
                  avatar="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80"
                  isShort={selectedTab === 'shorts'}
                />
              </div>
            )}

            <div className="flex justify-end space-x-4">
              <Button variant="secondary">
                <Calendar className="w-4 h-4 mr-2" />
                Schedule
              </Button>
              <Button 
                onClick={handleUpload} 
                disabled={isUploading || !files.length}
              >
                <Upload className="w-4 h-4 mr-2" />
                {isUploading ? 'Uploading...' : 'Upload to YouTube'}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}