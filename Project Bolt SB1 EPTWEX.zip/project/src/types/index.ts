export type SocialPlatform = 
  | 'instagram'
  | 'facebook'
  | 'twitter'
  | 'youtube'
  | 'tiktok'
  | 'snapchat'
  | 'linkedin'
  | 'pinterest';

export interface SocialMetrics {
  likes: number;
  comments: number;
  shares: number;
  posts: number;
  engagement: number;
  reach: number;
}

export interface Post {
  id: string;
  platform: SocialPlatform;
  content: string;
  media?: string[];
  scheduledFor?: Date;
  status: 'draft' | 'scheduled' | 'published' | 'failed';
  analytics?: {
    likes: number;
    comments: number;
    shares: number;
    reach: number;
  };
  createdAt: Date;
  updatedAt: Date;
}

export interface SocialAccount {
  id: string;
  platform: SocialPlatform;
  username: string;
  profileImage: string;
  metrics: SocialMetrics;
  isConnected: boolean;
  lastPostDate?: Date;
}

export type AccountType = 'influencer' | 'startup' | 'agency' | 'enterprise';

export interface User {
  id: string;
  name: string;
  email: string;
  avatar: string;
  theme: 'light' | 'dark';
  accounts: SocialAccount[];
  accountType?: AccountType;
  industry?: string;
  teamSize?: number;
  goals?: string[];
  onboardingCompleted: boolean;
  organization?: {
    id: string;
    name: string;
    role: 'admin' | 'editor' | 'viewer';
  };
}